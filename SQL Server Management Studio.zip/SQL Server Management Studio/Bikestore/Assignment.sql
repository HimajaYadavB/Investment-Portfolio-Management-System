﻿--1.List the customer_Id, Order_Year,Order_count of the customers who have placed 
--at least 2 orders per year 
select *from sales.orders
select customer_id, year(order_date), count(*) ct
from sales.orders
group by customer_id, year(order_date)
having count(*)>=2;

--2. List the product_id, List_price of the products located in store id 1 and 
--has a quantity greater than or equal to 30 
select *from production.products;
select *from production.stocks;
select *from sales.stores;

select s.product_id, list_price
from production.stocks s join production.products p 
on s.product_id=p.product_id 
where store_id=1 and quantity>=30;

--3. List the product_name, category_name and  list_price 
select product_name,category_name,list_price
from production.products p join production.categories c 
on p.category_id=c.category_id

--4. List all the product_name,list_price and order_id (show products without 
--order too) 
select *from sales.order_items
select *from sales.orders

select product_name, oi.list_price, oi.order_id
from sales.order_items oi join sales.orders o on oi.order_id=o.order_id
right join production.products p on p.product_id=oi.product_id;

--5. List customers first_name, last_name with order_id, order_date, 
--product_name,list_price and category_name 
select first_name, last_name, o.order_id, o.order_date, product_name, 
oi.list_price,category_name
from sales.customers c join sales.orders o 
on c.customer_id=o.customer_id join sales.order_items oi 
on oi.order_id=o.order_id join production.products p 
on oi.product_id=p.product_id join production.categories ct 
on ct.category_id=p.category_id;


--6. List the total_sales of each order (total_sales=list_price*quantity) 
--in descending order of total_sales(ignore the discount) 
select order_id, sum(list_price*quantity) total_sales
from sales.order_items
group by order_id 
order by total_sales desc;

--7. List the details of the stores with highest sales(use the above query)
with highsales as(
	select top 1 order_id, sum(list_price*quantity) total_sales
	from sales.order_items
	group by  order_id 
	order by total_sales desc
)
select *from sales.stores where store_id in(
	select store_id from sales.orders where order_id in (
		select order_id from highsales));

--8. Create a view to list product_id,product_name,list_price, brand_name,category_name
create view view1 as
select product_id, product_name, list_price, brand_name, category_name
from production.products p join production.categories c on p.category_id=c.category_id
join production.brands b on p.brand_id=b.brand_id
select *from view1;

--9. Create a Stored Procedure to list the product_name of all the products less than 
--the given list_price 
create or alter proc proc1 @lp decimal(10,2)
as
begin
	select *from production.products where list_price<@lp
end

exec proc1 1320

--10. Create  stored procedure finds products by model year and returns the number 
--of products via a output parameter 
create or alter proc proc2 @year int
as 
begin
	select *from production.products where model_year=@year;
end

exec proc2 2016


select hiredate from emp order by hiredate desc
select round(123.456,2)
declare @x 