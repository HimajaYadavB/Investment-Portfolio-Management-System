select *from Brokers;


ALTER TABLE brokers
ADD password VARCHAR(255);

UPDATE brokers
SET password = 'abc123'
WHERE BrokerID = 1;

UPDATE brokers
SET password = 'xyz123'
WHERE BrokerID = 2;

UPDATE brokers
SET password = 'mno123'
WHERE BrokerID = 3;

UPDATE brokers
SET password = 'pqr123'
WHERE BrokerID = 4;

UPDATE brokers
SET password = 'def123'
WHERE BrokerID = 5;

UPDATE brokers
SET password = 'lmn123'
WHERE BrokerID = 6;


-- 1. Add Email column
ALTER TABLE Brokers
ADD Email NVARCHAR(255);

-- 2. Update each broker with a specific email
UPDATE Brokers
SET Email = 'abc@broker.com'
WHERE BrokerID = 1;

UPDATE Brokers
SET Email = 'xyz@broker.com'
WHERE BrokerID = 2;

UPDATE Brokers
SET Email = 'mno@broker.com'
WHERE BrokerID = 3;

UPDATE Brokers
SET Email = 'pqr@broker.com'
WHERE BrokerID = 4;

UPDATE Brokers
SET Email = 'def@broker.com'
WHERE BrokerID = 5;

UPDATE Brokers
SET Email = 'lmn@broker.com'
WHERE BrokerID = 6;

ALTER TABLE Brokers
ADD IsApproved BIT DEFAULT 0;


-- Set IsApproved = 0 for first three brokers
UPDATE Brokers
SET IsApproved = 0
WHERE BrokerID IN (1, 2, 3);

-- Set IsApproved = 1 for next three brokers
UPDATE Brokers
SET IsApproved = 1
WHERE BrokerID IN (4, 5, 6);
sp_help Brokers