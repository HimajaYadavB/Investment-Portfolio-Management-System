/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [PortfolioID]
      ,[UserID]
      ,[PortfolioName]
      ,[PortfolioType]
      ,[DateCreated]
      ,[IsApproved]
  FROM [Portfolio_management].[dbo].[Portfolios]

CREATE TYPE PortfolioTVP AS TABLE (
  UserID INT,
  PortfolioName VARCHAR(100),
  PortfolioType VARCHAR(50),
  DateCreated DATETIME
);

CREATE PROCEDURE InsertPortfoliosBulk
  @PortfolioTVP PortfolioTVP READONLY
AS
BEGIN
  INSERT INTO Portfolios (UserID, PortfolioName, PortfolioType, DateCreated, IsApproved)
  SELECT UserID, PortfolioName, PortfolioType, DateCreated, 0 FROM @PortfolioTVP
END





CREATE TYPE AssetTableTypeNew AS TABLE
(
  PortfolioID INT,
  AssetName VARCHAR(100),
  AssetType VARCHAR(100),
  Quantity INT,
  CurrentPrice DECIMAL(10, 2),
  DatePurchased DATETIME,
  IsApproved BIT
);

CREATE or alter PROCEDURE InsertAssetsBulk
  @AssetsTVP AssetTableTypeNew READONLY
AS
BEGIN
  INSERT INTO Assets (PortfolioID, AssetName, AssetType, Quantity, CurrentPrice, DatePurchased, IsApproved)
  SELECT 
    PortfolioID, AssetName, AssetType, Quantity, CurrentPrice, DatePurchased, IsApproved
  FROM @AssetsTVP;
END



