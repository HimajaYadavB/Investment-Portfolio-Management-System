select *from sys.tables;
drop type StockPurchaseTableType
CREATE TYPE StockPurchaseTableType AS TABLE
(
    UserID INT,
    PortfolioID INT,
    AssetID INT,
	AssetName Varchar(100),
    Quantity INT,
    Price DECIMAL(10,2),
    BrokerID INT
);
GO

drop proc BuyStock
go
CREATE OR ALTER PROCEDURE BuyStock
    @StockPurchases StockPurchaseTableType READONLY  -- Table type parameter
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Insert transaction records for buying stocks
    INSERT INTO Transactions (UserID, PortfolioID, AssetID, Quantity, Price, TransactionType, TransactionDate, BrokerID)
    SELECT UserID, PortfolioID, AssetID, Quantity, Price, 'Buy', GETDATE(), BrokerID
    FROM @StockPurchases;

    -- 2. Update asset prices in the Assets table
	--Done in the backend 

    -- 3. Insert new asset prices into AssetPrices table
    INSERT INTO AssetPrices (AssetName, Price, Date)
    SELECT AssetName, Price, GETDATE()
    FROM @StockPurchases;

    -- 4. Insert commission fees into CommissionFees table
    INSERT INTO CommissionFees (UserID, PortfolioID, AssetID, BrokerID, FeeAmount, FeeDate, TotalAmount, CommissionPercent)
    SELECT 
        SP.UserID, 
        SP.PortfolioID, 
        SP.AssetID, 
        SP.BrokerID, 
        SP.Quantity * SP.Price * (B.CommissionRate / 100),  -- Commission Fee Calculation
        GETDATE(), 
        SP.Quantity * SP.Price,  -- Total Amount
        B.CommissionRate
    FROM @StockPurchases SP
    INNER JOIN Brokers B ON SP.BrokerID = B.BrokerID;  -- Fetch commission rate from Brokers table
END;
GO


DECLARE @StockPurchases StockPurchaseTableType;

-- Insert sample purchase data
INSERT INTO @StockPurchases (UserID, PortfolioID, AssetID, AssetName, Price, BrokerID)
VALUES (2, 2, 5, 200, 150.75, 2);

-- Call the procedure with the table type parameter
EXEC BuyStock @StockPurchases;

GO

CREATE OR ALTER PROCEDURE SellStock
    @UserID INT,
    @PortfolioID INT,
    @AssetID INT,
    @Quantity INT,
    @SellPrice DECIMAL(10, 2),
    @BrokerID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @CommissionRate DECIMAL(5, 2);
    DECLARE @FeeAmount DECIMAL(10, 2);
    DECLARE @TotalBuyQuantity INT;
    DECLARE @TotalBuyPrice DECIMAL(10, 2);
    DECLARE @ProfitLoss DECIMAL(10, 2);
    DECLARE @TotalSellValue DECIMAL(10, 2);
    DECLARE @TotalAmount DECIMAL(10, 2);
    DECLARE @ROI DECIMAL(10, 2);
    DECLARE @TotalVal DECIMAL(10, 2);
	DECLARE @prevProfitLoss DECIMAL(10, 2);
	DECLARE @TaxAmount DECIMAL(10, 2);

    -- Check if sufficient quantity is available to sell
    SELECT @TotalBuyQuantity = SUM(Quantity)
    FROM Transactions
    WHERE UserID = @UserID 
      AND PortfolioID = @PortfolioID 
      AND AssetID = @AssetID 
      AND TransactionType = 'Buy';

    IF @TotalBuyQuantity < @Quantity
    BEGIN
        PRINT 'Error: Insufficient quantity to sell.';
        RETURN;
    END;

    -- Insert a transaction record for selling the stock
    INSERT INTO Transactions (UserID, PortfolioID, AssetID, Quantity, Price, TransactionType, TransactionDate, BrokerID)
    VALUES (@UserID, @PortfolioID, @AssetID, @Quantity, @SellPrice, 'Sell', GETDATE(), @BrokerID);

    -- Calculate total cost of bought assets for the sold quantity
    SELECT @TotalBuyPrice = SUM(@Quantity * Price)
    FROM Transactions
    WHERE UserID = @UserID 
      AND PortfolioID = @PortfolioID 
      AND AssetID = @AssetID 
      AND TransactionType = 'Buy';
    
    INSERT INTO AssetPrices (AssetID, Price, Date)
    VALUES (@AssetID, @SellPrice, GETDATE());

    -- Fetch commission rate for the broker
    SELECT @CommissionRate = CommissionRate
    FROM Brokers
    WHERE BrokerID = @BrokerID;

    -- Calculate commission fee
    SET @FeeAmount = @Quantity * @SellPrice * (@CommissionRate / 100);

    -- Insert the commission fee into CommissionFees table
    SET @TotalAmount = @SellPrice * @Quantity;

    INSERT INTO CommissionFees (UserID, PortfolioID, AssetID, BrokerID, FeeAmount, FeeDate, TotalAmount, CommissionPercent)
    VALUES (@UserID, @PortfolioID, @AssetID, @BrokerID, @FeeAmount, GETDATE(), @TotalAmount, @CommissionRate);

    -- Calculate total sell value and profit/loss
    SET @TotalSellValue = @Quantity * @SellPrice;
    SET @ProfitLoss = @TotalSellValue - @TotalBuyPrice;
    
    -- Debugging select to verify the calculations
    SELECT @TotalBuyPrice AS TBC, @TotalSellValue AS TSV, @ProfitLoss AS PL;

    -- Retrieve current values for Performance table before updating
	-- COALESCE to return the first non null valuefrom a list of expressions.
    SELECT @TotalVal = COALESCE(TotalValue, 0),
           @prevProfitLoss = COALESCE(ProfitLoss, 0)
    FROM Performance
    WHERE PortfolioID = @PortfolioID;

    -- Debugging select for checking current values
    SELECT @TotalVal AS CurrentTotalValue, @prevProfitLoss AS CurrentProfitLoss;

    -- Update the Performance table
    -- Check if an entry exists for the given PortfolioID
	IF NOT EXISTS (
		SELECT 1
		FROM Performance
		WHERE PortfolioID = @PortfolioID
	)
	BEGIN
		-- Insert a new row if it doesn't exist
		INSERT INTO Performance (PortfolioID, TotalValue, ProfitLoss, ROI, DateMeasured)
		VALUES (@PortfolioID, 
				@TotalSellValue - @TotalBuyPrice, -- Initial TotalValue calculation
				@ProfitLoss,                     -- Initial ProfitLoss
				CASE 
					WHEN @TotalSellValue - @TotalBuyPrice = 0 THEN 0
					ELSE (@ProfitLoss / NULLIF(@TotalSellValue - @TotalBuyPrice, 0)) * 100
				END,                             -- Calculate ROI safely
				GETDATE()                        -- Current date and time
		);
	END
	ELSE
	BEGIN
		-- Update the existing row if it exists
		UPDATE Performance
		SET TotalValue = @TotalVal - @TotalBuyPrice + @TotalSellValue,
			ProfitLoss = @prevProfitLoss + @ProfitLoss,
			ROI = (ProfitLoss / NULLIF(TotalValue, 0)) * 100,
			DateMeasured = GETDATE()
		WHERE PortfolioID = @PortfolioID;
	END;

    
    -- Check updated values
    SELECT TotalValue, ProfitLoss, ROI
    FROM Performance
    WHERE PortfolioID = @PortfolioID;

	--Update transactions with the remaining quantity
	UPDATE Transactions
	SET Quantity = @TotalBuyQuantity - @Quantity
		
    WHERE UserID = @UserID 
      AND PortfolioID = @PortfolioID 
      AND AssetID = @AssetID 
      AND TransactionType = 'Buy';
	  
	  
	  --Update current price in the Assets table
	  UPDATE Assets
	  SET CurrentPrice = @SellPrice
	  WHERE AssetID = @AssetID 
      AND PortfolioID = @PortfolioID 

	  IF @ProfitLoss > 0
	  BEGIN
		
		SET @TaxAmount = @ProfitLoss * 0.1;

		INSERT INTO TaxPayments (UserID, TaxAmount, TaxType, PaymentDate)
        VALUES (@UserID, @TaxAmount, 'Capital Gains Tax', GETDATE());
	  END
END;
GO
-- update performance set totalvalue = 20062, profitloss = 1988, roi = 10.75 where performanceid =1;

INSERT INTO Transactions (UserID, PortfolioID, AssetID, Quantity, Price, TransactionType, TransactionDate, BrokerID)
    VALUES (2, 2, 5, 100, 990, 'Buy', GETDATE(),5);


EXEC SellStock @UserID = 2, 
               @PortfolioID = 2, 
               @AssetID = 5,  
               @Quantity = 20, 
               @SellPrice = 2000.00, 
               @BrokerID = 6;

 delete from transactions where assetId=5;


select *from Transactions;
select *from CommissionFees;
select *from AssetPrices;
select *from Performance;
select *from Assets;
select *from Portfolios;



select *from sys.tables;

alter table Assets
drop column PurchasePrice;

select *from AssetPrices;

--Determine the price trend:
CREATE OR ALTER PROCEDURE GetAssetPriceHistory
    @AssetID INT
AS
BEGIN
    -- Current Price (Most recent entry)
    SELECT TOP 1
        @AssetID AS AssetID,
        Price AS CurrentPrice,
        Date AS PriceDate
    FROM AssetPrices
    WHERE AssetID = @AssetID
    ORDER BY Date DESC;

    -- Historical Price Data (All price entries)
    SELECT 
        Date,
        Price
    FROM AssetPrices
    WHERE AssetID = @AssetID
    ORDER BY Date;

		--Calculate the price change percentage
		-- Step 1: Create a temporary table with a NULL PrevPrice column
	CREATE TABLE #TempAssetPrices (
		AssetID INT,
		Date DATE,
		Price DECIMAL(10,2),
		PrevPrice DECIMAL(10,2) NULL
	);

	-- Step 2: Insert all asset prices into the temporary table
	INSERT INTO #TempAssetPrices (AssetID, Date, Price, PrevPrice)
	SELECT AssetID, Date, Price, CAST(NULL AS DECIMAL(10,2))
	FROM AssetPrices
	WHERE AssetID = @AssetID;

	-- Step 3: Update PrevPrice with the latest available price before the current date
	WITH RankedPrices AS (
		SELECT 
			P.AssetID,
			P.Date,
			P.Price,
			ROW_NUMBER() OVER (PARTITION BY P.AssetID ORDER BY P.Date DESC) AS RowNum
		FROM AssetPrices P
		WHERE P.AssetID = @AssetID
	)
	UPDATE T
	SET T.PrevPrice = RP.Price
	FROM #TempAssetPrices T
	JOIN RankedPrices RP 
		ON T.AssetID = RP.AssetID 
		AND RP.Date < T.Date
	WHERE RP.Date = (SELECT MAX(Date) 
                 FROM AssetPrices 
                 WHERE AssetID = T.AssetID 
                   AND Date < T.Date);
		
	-- Step 4: Calculate and retrieve price change percentage
	SELECT 
		AssetID,
		Date,
		Price,
		PrevPrice,
		CASE 
			WHEN PrevPrice IS NULL THEN NULL  -- No previous price available
			ELSE ((Price - PrevPrice) / PrevPrice) * 100
		END AS PriceChangePercentage
	FROM #TempAssetPrices
	ORDER BY Date;

-- Step 5: Drop the temporary table after use
DROP TABLE #TempAssetPrices;



    -- Highest and Lowest Price
    SELECT 
        @AssetID AS AssetID,
        MAX(Price) AS HighestPrice,
        MIN(Price) AS LowestPrice
    FROM AssetPrices
    WHERE AssetID = @AssetID;

    -- Price Trend (Upward, Downward, or No Change)
    DECLARE @LatestPrice DECIMAL(10, 2);
	DECLARE @SecondLatestPrice DECIMAL(10, 2);
	DECLARE @ThirdLatestPrice DECIMAL(10, 2);

	WITH RecentPrices AS (
		SELECT 
			AssetID,
			Price,
			ROW_NUMBER() OVER (PARTITION BY AssetID ORDER BY Date DESC) AS PriceRank
		FROM AssetPrices
		WHERE AssetID = @AssetID
	)
	-- Fetch the latest 3 prices into variables
	SELECT 
    @LatestPrice = MAX(CASE WHEN PriceRank = 1 THEN Price END),
    @SecondLatestPrice = MAX(CASE WHEN PriceRank = 2 THEN Price END),
    @ThirdLatestPrice = MAX(CASE WHEN PriceRank = 3 THEN Price END)
	FROM RecentPrices
	WHERE AssetID = @AssetID;

	-- Determine the price trend
	SELECT 
		@AssetID AS AssetID,
		CASE 
			WHEN @LatestPrice > @SecondLatestPrice AND @SecondLatestPrice > @ThirdLatestPrice THEN 'Upward Trend'
			WHEN @LatestPrice < @SecondLatestPrice AND @SecondLatestPrice < @ThirdLatestPrice THEN 'Downward Trend'
			ELSE 'No Clear Trend'
		END AS PriceTrend;

END;




EXEC GetAssetPriceHistory @AssetID = 1;



/*CREATE OR ALTER PROCEDURE DepositDividends
	@assetID INT,
	@dividendAmount DECIMAL(10,2),
	@dividendRate DECIMAL(5,2)
AS
BEGIN
	DECLARE @taxAmount DECIMAL(10,2);

	INSERT INTO Dividends(AssetID, DividendAmount, DividendRate, PaymentDate)
	VALUES(@assetID, @dividendAmount, @dividendRate,GETDATE());

	SET @taxAmount = @dividendAmount * 0.1
	INSERT INTO TaxPayments (UserID, TaxAmount, TaxType, PaymentDate)
        VALUES (@UserID, @TaxAmount, 'Capital Gains Tax', GETDATE());
END

*/
select *from sys.tables;
select *from dividends;
select *from TaxPayments;


--procedure to make an entry into the tax table whenever there is an entry into the dividends table.
CREATE OR ALTER PROCEDURE AddDividendsTax 
	@userID INT,
	@assetID INT,
	@portfolioID INT,
	@dividendAmount DECIMAL(10,2),
	@dividendRate DECIMAL(5,2)
	
AS
BEGIN
	DECLARE @taxAmount DECIMAL(10,2)

	INSERT INTO Dividends(UserID, AssetID, PortfolioID, DividendAmount, DividendRate, PaymentDate) 
	VALUES(@userID, @assetID, @portfolioID, @dividendAmount, @dividendRate, GETDATE());

	SET @taxAmount = @dividendAmount * 0.1;

	INSERT INTO TaxPayments(UserID, TaxAmount, TaxType, PaymentDate)
	VALUES(@userID, @taxAmount, 'Dividend Tax', GETDATE());

END


EXEC AddDividendsTax 1,1,1,250
select *from Goals;

CREATE OR ALTER PROCEDURE TrackGoalProgess
	@userID INT
AS
BEGIN
	SELECT
		GoalName, GoalAmount, CurrentAmount, 
		(currentAmount / GoalAmount) * 100 AS CompletePercent,
		CASE
			WHEN CurrentAmount>=GoalAmount THEN 'Goal Achieved'
			WHEN GoalDate < GETDATE() THEN 'Overdue'
            ELSE 'In Progress'
		END AS GoalStatus
	FROM Goals
	WHERE UserID = @userID;
			
END;

EXEC TrackGoalProgess 1




CREATE OR ALTER PROCEDURE SummarizeUserGoals
    @UserID INT
AS
BEGIN
    SELECT 
        COUNT(*) AS TotalGoals,
        SUM(GoalAmount) AS TotalGoalAmount,
        SUM(CurrentAmount) AS TotalSavedAmount,
        COUNT(CASE WHEN CurrentAmount >= GoalAmount THEN 1 END) AS GoalsAchieved
    FROM Goals
    WHERE UserID = @UserID;
END;

EXEC SummarizeUserGoals 1




CREATE OR ALTER PROCEDURE PredictGoalCompletion
    @GoalID INT,
    @MonthlyContribution DECIMAL(10, 2)
AS
BEGIN
    DECLARE @RemainingAmount DECIMAL(10, 2);
    DECLARE @MonthsToComplete INT;

    SELECT @RemainingAmount = GoalAmount - CurrentAmount
    FROM Goals
    WHERE GoalID = @GoalID;

    SET @MonthsToComplete = CEILING(@RemainingAmount / @MonthlyContribution);

    SELECT 
        GoalName,
        GoalAmount,
        CurrentAmount,
		@MonthsToComplete AS ExpectedMonths,
        DATEADD(MONTH, @MonthsToComplete, GETDATE()) AS ExpectedCompletionDate
    FROM Goals
    WHERE GoalID = @GoalID;
END;

EXEC PredictGoalCompletion 1, 5000



CREATE OR ALTER PROC DisplayDividends
	@UserID int,
	@PortfolioID , 