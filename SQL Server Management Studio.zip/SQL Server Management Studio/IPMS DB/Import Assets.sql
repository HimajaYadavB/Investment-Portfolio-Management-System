/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [AssetID]
      ,[PortfolioID]
      ,[AssetName]
      ,[AssetType]
      ,[Quantity]
      ,[CurrentPrice]
      ,[DatePurchased]
      ,[IsApproved]
  FROM [Portfolio_management].[dbo].[Assets]


  ALTER TABLE Assets
ADD CONSTRAINT DF_Assets_IsApproved DEFAULT 0 FOR IsApproved;

SELECT name
FROM sys.default_constraints
WHERE parent_object_id = OBJECT_ID('Assets')
  AND parent_column_id = (
    SELECT column_id
    FROM sys.columns
    WHERE object_id = OBJECT_ID('Assets')
      AND name = 'IsApproved'
  );


  ALTER TABLE Assets
DROP CONSTRAINT DF__Assets__IsApprov__3B40CD36;


ALTER TABLE Assets
ADD CONSTRAINT DF_Assets_IsApproved DEFAULT 0 FOR IsApproved;


SELECT c.name AS ColumnName, d.definition AS DefaultValue
FROM sys.columns c
JOIN sys.default_constraints d ON c.default_object_id = d.object_id
WHERE c.object_id = OBJECT_ID('Assets') AND c.name = 'IsApproved';
