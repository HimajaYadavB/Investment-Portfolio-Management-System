CREATE DATABASE Portfolio_management;
USE Portfolio_management;

select *from sys.databases;
select *from sys.tables;

--Creating users table
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FirstName VARCHAR(100),
    LastName VARCHAR(100),
    Email VARCHAR(100) UNIQUE,
    Password VARCHAR(255),
    DateOfBirth DATE,
    Address text,
    PhoneNumber VARCHAR(15)
);

INSERT INTO Users (FirstName, LastName, Email, Password, DateOfBirth, Address, PhoneNumber)
VALUES
('Himaja', 'Reddy', 'himaja.reddy@example.com', 'passHimaja123', '1999-04-05', '123 Palm Street, Hyderabad', '9876543210'),
('Latha', 'Sharma', 'latha.sharma@example.com', 'secureLatha456', '1995-08-12', '456 Rose Lane, Bangalore', '9123456789'),
('Kavya', 'Verma', 'kavya.verma@example.com', 'kavyaPass789', '1997-03-22', '789 Lily Road, Pune', '9345678123'),
('Suresh', 'Patil', 'suresh.patil@example.com', 'sureshSecure2023', '1994-06-15', '321 Lotus Avenue, Mumbai', '9234567890'),
('Nitya', 'Mohan', 'nitya.mohan@example.com', 'nityaPassword01', '2000-01-30', '654 Orchid Blvd, Chennai', '9456781230'),
('Arun', 'Kumar', 'arun.kumar@example.com', 'arunKumarPass', '1993-10-18', '987 Tulip Drive, Delhi', '9876540987');


select *from Users;
drop table PortfolioTypes
CREATE TABLE PortfolioTypes (
    PortfolioType VARCHAR(50) PRIMARY KEY
);

INSERT INTO PortfolioTypes (PortfolioType)
VALUES ('Growth'), ('Stable'), ('Aggressive'), ('Income'), ('Sector-Specific'), ('Socially Responsible'), ('Diversified');

-- Update Assets table to reference AssetTypes
ALTER TABLE Portfolios
DROP CONSTRAINT CHK_PortfolioType;

ALTER TABLE Portfolios
ADD CONSTRAINT FK_PortfolioType FOREIGN KEY (PortfolioType) REFERENCES PortfolioTypes(PortfolioType);

CREATE TABLE Portfolios (
    PortfolioID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT,
    PortfolioName VARCHAR(100),
    PortfolioType VARCHAR(50),
    DateCreated DATETIME,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    CONSTRAINT CHK_PortfolioType CHECK (PortfolioType IN ('Growth', 'Stable', 'Aggressive', 'Income', 'Sector-Specific', 'Socially Responsible', 'Diversified'))
);


INSERT INTO Portfolios (UserID, PortfolioName, PortfolioType, DateCreated)
VALUES
(1, 'Tech Innovators Fund', 'Growth', '2025-01-01 09:30:00'),
(2, 'Safe Bonds Portfolio', 'Stable', '2025-01-02 10:00:00'),
(3, 'Startups Equity Fund', 'Aggressive', '2025-01-03 14:45:00'),
(4, 'Dividend Generators', 'Income', '2025-01-04 11:15:00'),
(5, 'Healthcare Giants', 'Sector-Specific', '2025-01-05 13:30:00'),
(6, 'Green Investments', 'Socially Responsible', '2025-01-06 15:00:00'),
(6, 'Global Diversified Portfolio', 'Diversified', '2025-01-07 12:00:00'),
(1, 'Emerging Markets Fund', 'Growth', '2025-01-08 16:30:00'),
(3, 'Energy Sector Focus', 'Sector-Specific', '2025-01-09 10:45:00'),
(4, 'Sustainable Income Fund', 'Income', '2025-01-10 14:00:00');

select *from Portfolios;

CREATE TABLE AssetTypes (
    AssetType VARCHAR(100) PRIMARY KEY
);

INSERT INTO AssetTypes (AssetType)
VALUES ('Stock'), ('Bond'), ('ETF'), ('Cryptocurrency'), ('Real Estate'), ('Commodities'), ('Mutual Funds');

-- Update Assets table to reference AssetTypes
ALTER TABLE Assets
DROP CONSTRAINT AssetType_CHK;

ALTER TABLE Assets
ADD CONSTRAINT FK_AssetType FOREIGN KEY (AssetType) REFERENCES AssetTypes(AssetType);

CREATE TABLE Assets (
    AssetID INT PRIMARY KEY IDENTITY(1,1),
    PortfolioID INT,
    AssetName VARCHAR(100),
    AssetType VARCHAR(100),
    Quantity INT,
    PurchasePrice DECIMAL(10, 2),
    CurrentPrice DECIMAL(10, 2),
    DatePurchased DATETIME,
    FOREIGN KEY (PortfolioID) REFERENCES Portfolios(PortfolioID),

);


INSERT INTO Assets (PortfolioID, AssetName, AssetType, Quantity, PurchasePrice, CurrentPrice, DatePurchased)
VALUES
(1, 'Apple Inc. Stock', 'Stock', 100, 150.00, 160.00, '2025-01-01'),
(1, 'Tesla Inc. Stock', 'Stock', 50, 650.00, 670.00, '2025-01-02'),
(1, 'Amazon.com Stock', 'Stock', 80, 3300.00, 3350.00, '2025-01-03'),
(2, 'US Treasury Bond', 'Bond', 50, 1000.00, 1025.00, '2025-01-04'),
(2, 'Municipal Bonds', 'Bond', 40, 950.00, 980.00, '2025-01-05'),
(3, 'Vanguard Total Stock Market ETF', 'ETF', 200, 180.00, 190.00, '2025-01-06'),
(3, 'iShares Russell 2000 ETF', 'ETF', 150, 210.00, 215.00, '2025-01-07'),
(4, 'Coca-Cola Dividend Stock', 'Stock', 150, 45.00, 47.00, '2025-01-08'),
(4, 'Procter & Gamble Dividend Stock', 'Stock', 200, 120.00, 125.00, '2025-01-09'),
(4, 'Johnson & Johnson Dividend Stock', 'Stock', 100, 170.00, 175.00, '2025-01-10'),
(5, 'Johnson & Johnson Stock', 'Stock', 75, 170.00, 175.00, '2025-01-11'),
(5, 'Pfizer Inc. Stock', 'Stock', 100, 40.00, 42.00, '2025-01-12'),
(6, 'Tesla Green Bonds', 'Bond', 20, 1000.00, 1050.00, '2025-01-13'),
(6, 'SPDR S&P 500 ETF', 'ETF', 100, 350.00, 360.00, '2025-01-14'),
(7, 'Vanguard Real Estate ETF', 'ETF', 50, 210.00, 215.00, '2025-01-15'),
(7, 'SPDR Gold Shares', 'ETF', 30, 1800.00, 1850.00, '2025-01-16'),
(8, 'Microsoft Stock', 'Stock', 120, 300.00, 320.00, '2025-01-17'),
(8, 'Alphabet Inc. Stock', 'Stock', 80, 2800.00, 2900.00, '2025-01-18'),
(9, 'Energy Select Sector SPDR Fund', 'ETF', 150, 70.00, 75.00, '2025-01-19'),
(9, 'XLE Energy ETF', 'ETF', 100, 65.00, 68.00, '2025-01-20'),
(10, 'Bitcoin Cryptocurrency', 'Cryptocurrency', 10, 30000.00, 31000.00, '2025-01-21'),
(10, 'Ethereum Cryptocurrency', 'Cryptocurrency', 15, 2000.00, 2100.00, '2025-01-22'),
(10, 'Gold ETF', 'ETF', 50, 1800.00, 1850.00, '2025-01-23'),
(10, 'SPDR S&P 500 ETF', 'ETF', 100, 350.00, 360.00, '2025-01-24');

select *from Assets;


CREATE TABLE Brokers (
    BrokerID INT PRIMARY KEY IDENTITY(1,1),
    BrokerName VARCHAR(100),
    ContactDetails VARCHAR(255),
    CommissionRate DECIMAL(5, 2),
    LicenseNumber VARCHAR(50)
);

INSERT INTO Brokers (BrokerName, ContactDetails, CommissionRate, LicenseNumber)
VALUES
('ABC Securities', '123 Market St, City, State, 555-1234', 2.50, 'LIC12345'),
('XYZ Investments', '456 Wall St, City, State, 555-5678', 1.80, 'LIC23456'),
('MNO Brokers', '789 High St, City, State, 555-9101', 3.00, 'LIC34567'),
('PQR Capital', '321 Broad St, City, State, 555-1122', 2.20, 'LIC45678'),
('DEF Trading', '654 Pine St, City, State, 555-3344', 1.95, 'LIC56789'),
('LMN Brokerage', '987 Oak St, City, State, 555-7788', 2.10, 'LIC67890');

select *from Brokers

CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT,
    PortfolioID INT,
    AssetID INT,
    TransactionType VARCHAR(100),
    Quantity INT,
    Price DECIMAL(10, 2),
    TransactionDate DATETIME,
    BrokerID INT,  -- Foreign key to Brokers Table
    CommissionFee DECIMAL(10, 2), -- Commission fee based on Broker's rate
	CONSTRAINT TransactionType_CHK CHECK(TransactionType IN ('Buy', 'Sell')),
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (PortfolioID) REFERENCES Portfolios(PortfolioID),
    FOREIGN KEY (AssetID) REFERENCES Assets(AssetID),
    FOREIGN KEY (BrokerID) REFERENCES Brokers(BrokerID) -- Reference to Brokers Table
);
ALTER TABLE Transactions
DROP COLUMN CommissionFee;


select *from Users;
select *from Portfolios;
select *from Assets;
select *from Brokers;


-- Insert Buy Transactions
INSERT INTO Transactions (UserID, PortfolioID, AssetID, TransactionType, Quantity, Price, TransactionDate, BrokerID)
VALUES
(1, 1, 1, 'Buy', 50, 150.00, '2025-01-01 09:30:00', 1),
(1, 1, 2, 'Buy', 30, 650.00, '2025-01-02 10:00:00', 1),
(1, 1, 3, 'Buy', 40, 3300.00, '2025-01-03 14:45:00', 1),
(2, 2, 4, 'Buy', 20, 1000.00, '2025-01-04 11:15:00', 2),
(2, 2, 5, 'Buy', 15, 950.00, '2025-01-05 13:30:00', 2),
(3, 3, 6, 'Buy', 100, 180.00, '2025-01-06 15:00:00', 3),
(3, 3, 7, 'Buy', 100, 210.00, '2025-01-07 12:00:00', 3),
(4, 4, 8, 'Buy', 50, 45.00, '2025-01-08 16:30:00', 4),
(4, 4, 9, 'Buy', 100, 120.00, '2025-01-09 10:45:00', 4),
(4, 4, 10, 'Buy', 50, 170.00, '2025-01-10 14:00:00', 4),
(5, 5, 11, 'Buy', 50, 170.00, '2025-01-11 00:00:00', 5),
(5, 5, 12, 'Buy', 60, 40.00, '2025-01-12 00:00:00', 5);

-- Insert Sell Transactions (Ensuring the asset is first bought)
INSERT INTO Transactions (UserID, PortfolioID, AssetID, TransactionType, Quantity, Price, TransactionDate, BrokerID)
VALUES
(1, 1, 1, 'Sell', 50, 155.00, '2025-01-02 09:30:00', 1),
(1, 1, 2, 'Sell', 30, 660.00, '2025-01-03 10:00:00', 1),
(1, 1, 3, 'Sell', 40, 3400.00, '2025-01-04 14:45:00', 1),
(2, 2, 4, 'Sell', 20, 1020.00, '2025-01-05 11:15:00', 2),
(2, 2, 5, 'Sell', 15, 985.00, '2025-01-06 13:30:00', 2),
(3, 3, 6, 'Sell', 100, 185.00, '2025-01-07 15:00:00', 3),
(3, 3, 7, 'Sell', 100, 215.00, '2025-01-08 12:00:00', 3),
(4, 4, 8, 'Sell', 50, 47.00, '2025-01-09 16:30:00', 4),
(4, 4, 9, 'Sell', 100, 125.00, '2025-01-10 10:45:00', 4),
(4, 4, 10, 'Sell', 50, 175.00, '2025-01-11 14:00:00', 4),
(5, 5, 11, 'Sell', 50, 172.00, '2025-01-12 00:00:00', 5),
(5, 5, 12, 'Sell', 60, 42.50, '2025-01-13 00:00:00', 5);


INSERT INTO Transactions (UserID, PortfolioID, AssetID, TransactionType, Quantity, Price, TransactionDate, BrokerID)
VALUES
(6, 6, 13, 'Buy', 30, 1000.00, '2025-01-13 15:00:00', 6),
(6, 6, 14, 'Buy', 50, 350.00, '2025-01-14 16:30:00', 6),
(6, 7, 15, 'Buy', 40, 210.00, '2025-01-15 12:00:00', 6),
(6, 7, 16, 'Buy', 25, 1800.00, '2025-01-16 12:45:00', 6),
(1, 8, 17, 'Buy', 30, 1850.00, '2025-01-17 10:30:00', 6),
(1, 8, 18, 'Buy', 60, 2900.00, '2025-01-18 14:00:00', 6);


INSERT INTO Transactions (UserID, PortfolioID, AssetID, TransactionType, Quantity, Price, TransactionDate, BrokerID)
VALUES
(6, 6, 13, 'Sell', 30, 1050.00, '2025-01-14 15:00:00', 6),
(6, 6, 14, 'Sell', 50, 360.00, '2025-01-15 16:30:00', 6),
(6, 7, 15, 'Sell', 40, 215.00, '2025-01-16 12:00:00', 6),
(6, 7, 16, 'Sell', 25, 1850.00, '2025-01-17 13:00:00', 6),
(1, 8, 17, 'Sell', 30, 1900.00, '2025-01-18 15:00:00', 6),
(1, 8, 18, 'Sell', 60, 2950.00, '2025-01-19 14:00:00', 6);



select *from Assets a left join Portfolios p on a.PortfolioID = p.PortfolioID


drop table AssetPrices

CREATE TABLE AssetPrices (
    PriceID INT PRIMARY KEY IDENTITY(1,1),
    AssetName VARCHAR(100),
    Date DATE,
    Price DECIMAL(10, 2),
    
);

-- Insert multiple random entries for AssetPrices for all asset IDs
INSERT INTO AssetPrices (AssetName, Date, Price)
VALUES
-- Apple Inc. Stock (AssetID 1)
('Apple Inc. Stock', '2025-01-01', 160.00),
('Apple Inc. Stock', '2025-01-02', 162.50),
('Apple Inc. Stock', '2025-01-03', 165.00),

-- Tesla Inc. Stock (AssetID 2)
('Tesla Inc. Stock', '2025-01-02', 670.00),
('Tesla Inc. Stock', '2025-01-03', 675.00),
('Tesla Inc. Stock', '2025-01-04', 680.00),

-- Amazon.com Stock (AssetID 3)
('Amazon.com Stock', '2025-01-03', 3350.00),
('Amazon.com Stock', '2025-01-04', 3380.00),

-- US Treasury Bond (AssetID 4)
('US Treasury Bond', '2025-01-04', 1025.00),
('US Treasury Bond', '2025-01-05', 1030.00),

-- Healthcare Giants (AssetID 5)
('Municipal Bonds', '2025-01-05', 990.00),
('Municipal Bonds', '2025-01-06', 995.00),
('Municipal Bonds', '2025-01-07', 1000.00),

-- Vanguard Total Stock Market ETF (AssetID 6)
('Vanguard Total Stock Market ETF', '2025-01-06', 190.00),
('Vanguard Total Stock Market ETF', '2025-01-07', 195.00),

-- iShares Russell 2000 ETF (AssetID 7)
('iShares Russell 2000 ETF', '2025-01-07', 215.00),
('iShares Russell 2000 ETF', '2025-01-08', 218.00),
('iShares Russell 2000 ETF', '2025-01-09', 220.00),

-- Coca-Cola Dividend Stock (AssetID 8)
('Coca-Cola Dividend Stock', '2025-01-08', 47.00),
('Coca-Cola Dividend Stock', '2025-01-09', 48.00),

-- Procter & Gamble Dividend Stock (AssetID 9)
('Procter & Gamble Dividend Stock', '2025-01-09', 125.00),
('Procter & Gamble Dividend Stock', '2025-01-10', 126.50),

-- Energy Select Sector SPDR Fund (AssetID 10)
('Johnson & Johnson Dividend Stock', '2025-01-19', 75.00),
('Johnson & Johnson Dividend Stock', '2025-01-20', 77.00),

-- Johnson & Johnson Stock (AssetID 11)
('Johnson & Johnson Stock', '2025-01-10', 175.00),
('Johnson & Johnson Stock', '2025-01-11', 178.00),

-- Pfizer Inc. Stock (AssetID 12)
('Pfizer Inc. Stock', '2025-01-12', 42.00),
('Pfizer Inc. Stock', '2025-01-13', 43.00),
('Pfizer Inc. Stock', '2025-01-14', 44.50),

-- Tesla Green Bonds (AssetID 13)
('Tesla Green Bonds', '2025-01-13', 1050.00),
('Tesla Green Bonds', '2025-01-14', 1060.00),

-- SPDR S&P 500 ETF (AssetID 14)
('SPDR S&P 500 ETF', '2025-01-14', 360.00),
('SPDR S&P 500 ETF', '2025-01-15', 362.00),

-- Vanguard Real Estate ETF (AssetID 15)
('Vanguard Real Estate ETF', '2025-01-15', 215.00),
('Vanguard Real Estate ETF', '2025-01-16', 220.00),

-- SPDR Gold Shares (AssetID 16)
('SPDR Gold Shares', '2025-01-16', 1850.00),
('SPDR Gold Shares', '2025-01-17', 1870.00),

-- Microsoft Stock (AssetID 17)
('Microsoft Stock', '2025-01-17', 320.00),
('Microsoft Stock', '2025-01-18', 325.00),
('Microsoft Stock', '2025-01-19', 330.00),

-- Alphabet Inc. Stock (AssetID 18)
('Alphabet Inc. Stock', '2025-01-18', 2900.00),
('Alphabet Inc. Stock', '2025-01-19', 2950.00),

-- XLE Energy ETF (AssetID 19)
('XLE Energy ETF', '2025-01-20', 68.00),
('XLE Energy ETF', '2025-01-21', 70.00),

-- Bitcoin Cryptocurrency (AssetID 20)
('Bitcoin Cryptocurrency', '2025-01-21', 31000.00),
('Bitcoin Cryptocurrency', '2025-01-22', 31200.00),

-- Ethereum Cryptocurrency (AssetID 21)
('Ethereum Cryptocurrency', '2025-01-22', 2100.00),
('Ethereum Cryptocurrency', '2025-01-23', 2150.00),

-- Gold ETF (AssetID 22)
('Gold ETF', '2025-01-23', 1850.00),
('Gold ETF', '2025-01-24', 1860.00),

-- SPDR S&P 500 ETF (AssetID 23)
('SPDR S&P 500 ETF', '2025-01-24', 360.00),
('SPDR S&P 500 ETF', '2025-01-25', 362.50),

-- SPDR S&P 500 ETF (AssetID 24)
('Vanguard Real Estate', '2025-01-24', 375.00),
('Vanguard Real Estate', '2025-01-25', 380.00),
('Vanguard Real Estate', '2025-01-26', 385.00);



CREATE TABLE Dividends (
    DividendID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT, -- Added to associate the dividend with a specific user
    AssetID INT,
    PortfolioID INT, -- Added to track which portfolio received the dividend
    DividendAmount DECIMAL(10, 2),
    DividendRate DECIMAL(5, 2),
    PaymentDate DATE,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (AssetID) REFERENCES Assets(AssetID),
    FOREIGN KEY (PortfolioID) REFERENCES Portfolios(PortfolioID) -- Assuming a Portfolios table exists
);


INSERT INTO Dividends (UserID, AssetID, PortfolioID, DividendAmount, DividendRate, PaymentDate)
VALUES 
    (1, 1, 1, 200.00, 2.00, '2025-01-25'),
    (1, 2, 1, 67.00, 1.50, '2025-01-26'),
    (1, 3, 1, 268.00, 2.00, '2025-01-27'),
    (2, 4, 2, 51.25, 1.00, '2025-01-28'),
    (2, 5, 2, 80.00, 2.00, '2025-01-29'),
    (3, 6, 3, 38.00, 2.00, '2025-01-30'),
    (3, 7, 3, 64.50, 3.00, '2025-01-31'),
    (4, 8, 4, 70.50, 2.50, '2025-02-01'),
    (4, 9, 4, 250.00, 2.00, '2025-02-02'),
    (4, 10, 4, 175.00, 3.00, '2025-02-03'),
    (5, 11, 5, 131.25, 2.50, '2025-02-04'),
    (5, 12, 5, 42.00, 1.00, '2025-02-05'),
    (6, 13, 6, 200.00, 2.50, '2025-02-06'),
    (6, 14, 6, 36.00, 1.50, '2025-02-07'),
    (6, 15, 7, 53.75, 2.50, '2025-02-08'),
    (6, 16, 7, 55.50, 3.00, '2025-02-09'),
    (1, 17, 8, 384.00, 4.00, '2025-02-10'),
    (1, 18, 8, 580.00, 2.00, '2025-02-11'),
    (3, 19, 9, 112.50, 1.50, '2025-02-12'),
    (3, 20, 9, 68.00, 1.00, '2025-02-13'),
    (4, 21, 10, 3100.00, 1.00, '2025-02-14'),
    (4, 22, 10, 315.00, 1.50, '2025-02-15'),
    (4, 23, 10, 92.50, 2.00, '2025-02-16'),
    (4, 24, 10, 72.00, 1.50, '2025-02-17');


select *from sys.tables;
select *from Dividends
select *from Portfolios;
select *from Assets;



CREATE TABLE Goals (
    GoalID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT,
    GoalName VARCHAR(100),
    GoalAmount DECIMAL(10, 2),
    GoalDate DATE,
    CurrentAmount DECIMAL(10, 2),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);


INSERT INTO Goals (UserID, GoalName, GoalAmount, GoalDate, CurrentAmount)
VALUES
(1, 'Retirement Fund', 50000.00, '2035-01-01', 12000.00),
(1, 'Vacation Fund', 15000.00, '2028-12-31', 5000.00),
(2, 'House Purchase', 300000.00, '2030-06-30', 50000.00),
(2, 'Car Fund', 30000.00, '2025-12-31', 15000.00),
(3, 'Child�s Education Fund', 20000.00, '2035-06-30', 8000.00),
(3, 'Emergency Fund', 10000.00, '2027-06-30', 4000.00),
(4, 'Investment in Stock Market', 100000.00, '2032-12-31', 20000.00),
(4, 'Home Renovation', 25000.00, '2026-06-30', 8000.00),
(5, 'Travel Fund', 12000.00, '2025-05-30', 6000.00),
(5, 'Business Startup Fund', 50000.00, '2029-08-15', 20000.00),
(6, 'Debt Repayment', 20000.00, '2024-12-31', 12000.00),
(6, 'Health Savings Fund', 10000.00, '2027-11-30', 3000.00);


CREATE TABLE RiskAssessment (
    RiskID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT,
    RiskLevel VARCHAR(100),
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
	CONSTRAINT RiskLevel_CHK CHECK (RiskLevel IN('Low', 'Medium', 'High'))
);

INSERT INTO RiskAssessment (UserID, RiskLevel)
VALUES
(1, 'High'),
(2, 'Medium'),
(3, 'Low'),
(4, 'High'),
(5, 'Medium'),
(6, 'Low');


CREATE TABLE Performance (
    PerformanceID INT PRIMARY KEY IDENTITY(1,1),
    PortfolioID INT,
    TotalValue DECIMAL(10, 2),
    ProfitLoss DECIMAL(10, 2),
    ROI DECIMAL(5, 2),  -- Return On Investment Percentage
    DateMeasured DATE,
    FOREIGN KEY (PortfolioID) REFERENCES Portfolios(PortfolioID)
);

INSERT INTO Performance (PortfolioID, TotalValue, ProfitLoss, ROI, DateMeasured)
VALUES 
(1, 800.00, 600.00, 60.00, '2025-01-21'),
(2, 750.00, 500.00, 50.00, '2025-01-21'),
(3, 2600.00, 900.00, 30.00, '2025-01-21'),
(4, 4650.00, 250.00, 3.33, '2025-01-21'),
(5, 5040.00, 240.00, 5.00, '2025-01-21'),
(6, 9360.00, 360.00, 4.00, '2025-01-21');


select *from Users;
select *from Portfolios;
select *from Assets;
select *from Brokers;



CREATE TABLE CommissionFees (
    CommissionFeeID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT,
    PortfolioID INT,
    AssetID INT,
    BrokerID INT,
    FeeAmount DECIMAL(10, 2),
    FeeDate DATETIME,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
    FOREIGN KEY (PortfolioID) REFERENCES Portfolios(PortfolioID),
    FOREIGN KEY (AssetID) REFERENCES Assets(AssetID),
    FOREIGN KEY (BrokerID) REFERENCES Brokers(BrokerID)
);


INSERT INTO CommissionFees (UserID, PortfolioID, AssetID, BrokerID, FeeAmount, FeeDate)
VALUES 
(1, 1, 3, 2, 12.50, '2025-01-20 10:15:00'),
(2, 2, 5, 4, 18.75, '2025-01-21 14:30:00'),
(3, 3, 6, 6, 22.00, '2025-01-22 11:45:00'),
(4, 4, 8, 1, 10.00, '2025-01-23 09:20:00'),
(5, 5, 11, 3, 25.50, '2025-01-24 16:50:00'),
(6, 6, 13, 5, 15.75, '2025-01-25 13:40:00'),
(1, 8, 17, 6, 11.00, '2025-01-26 08:10:00'),
(2, 2, 4, 4, 19.25, '2025-01-27 17:30:00'),
(3, 9, 20, 2, 14.00, '2025-01-28 10:05:00'),
(4, 10, 24, 1, 16.50, '2025-01-29 12:20:00');




CREATE TABLE TaxPayments (
    TaxPaymentID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT,
    TaxAmount DECIMAL(10, 2),
    TaxType VARCHAR(100),
    PaymentDate DATE,
    FOREIGN KEY (UserID) REFERENCES Users(UserID),
	CONSTRAINT TaxType_CHK CHECK (TaxType IN ('Capital Gains Tax', 'Dividend Tax'))
);


INSERT INTO TaxPayments (UserID, TaxAmount, TaxType, PaymentDate)
VALUES 
(1, 75.00, 'Capital Gains Tax', '2025-01-10'), -- User 1 sold an asset with capital gains
(2, 20.00, 'Dividend Tax', '2025-01-12'),      -- User 2 received dividends
(3, 120.00, 'Capital Gains Tax', '2025-01-15'), -- User 3 sold an asset with capital gains
(4, 15.00, 'Dividend Tax', '2025-01-17'),      -- User 4 received dividends
(5, 200.00, 'Capital Gains Tax', '2025-01-18'), -- User 5 sold an asset with large capital gains
(6, 25.00, 'Dividend Tax', '2025-01-20'),      -- User 6 received dividends
(1, 50.00, 'Capital Gains Tax', '2025-01-22'), -- User 1 sold another asset with capital gains
(2, 30.00, 'Dividend Tax', '2025-01-25'),      -- User 2 received dividends again
(3, 45.00, 'Capital Gains Tax', '2025-01-27'), -- User 3 sold a smaller asset
(4, 18.00, 'Dividend Tax', '2025-01-28'),      -- User 4 received dividends
(5, 60.00, 'Capital Gains Tax', '2025-01-30'), -- User 5 sold an asset with smaller gains
(6, 12.00, 'Dividend Tax', '2025-01-31');      -- User 6 received dividends again


select *from sys.tables;

select *from TaxPayments;
select *from sys.tables;
select *from Performance;