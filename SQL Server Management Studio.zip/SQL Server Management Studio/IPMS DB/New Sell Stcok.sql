CREATE TYPE StockPurchaseTableType AS TABLE
(
    UserID INT,
    PortfolioID INT,
    AssetID INT,
	AssetName Varchar(100),
    Quantity INT,
    Price DECIMAL(10,2),
    BrokerID INT
);
go
drop type StockSellTableType
GO
select *from Assets
GO
SELECT name, schema_id FROM sys.types WHERE name = 'StockSellTableType';

go

CREATE OR ALTER PROCEDURE UpdatedSellStock
    @StockSell StockPurchaseTableType READONLY -- Table type parameter
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables
    DECLARE @UserID INT, @PortfolioID INT, @AssetID INT, @SellQuantity INT, @SellPrice DECIMAL(10,2), @BrokerID INT, @AssetName VARCHAR(50);
    DECLARE @CommissionRate DECIMAL(5,2), @FeeAmount DECIMAL(10,2);
    DECLARE @TotalBuyQuantity INT, @TotalBuyPrice DECIMAL(10,2);
    DECLARE @ProfitLoss DECIMAL(10,2), @TotalSellValue DECIMAL(10,2), @TotalAmount DECIMAL(10,2);
    DECLARE @ROI DECIMAL(10,2), @TotalVal DECIMAL(10,2), @prevProfitLoss DECIMAL(10,2);
    DECLARE @TaxAmount DECIMAL(10,2);

    -- Extract values from table type (assuming one row per execution)
    SELECT TOP 1 
        @UserID = UserID,
        @PortfolioID = PortfolioID,
        @AssetID = AssetID,
		@AssetName = AssetName,
        @SellQuantity = Quantity,
        @SellPrice = Price,
        @BrokerID = BrokerID
    FROM @StockSell;

    -- Validate available quantity before selling
    SELECT @TotalBuyQuantity = Quantity 
    FROM Assets 
    WHERE PortfolioID = @PortfolioID 
      AND AssetID = @AssetID;

    -- Check if asset exists
    IF @TotalBuyQuantity IS NULL
    BEGIN
        PRINT 'Error: Asset not found for the given PortfolioID and AssetID.';
        RETURN;
    END;

    -- Check if the user has enough quantity to sell
    IF @TotalBuyQuantity < @SellQuantity
    BEGIN
        RAISERROR ('Error: Insufficient quantity to sell.', 16, 1);
		RETURN;
    END;

    -- Insert transaction record for selling stocks
    INSERT INTO Transactions (UserID, PortfolioID, AssetID, Quantity, Price, TransactionType, TransactionDate, BrokerID)
    SELECT UserID, PortfolioID, AssetID, Quantity, Price, 'Sell', GETDATE(), BrokerID
    FROM @StockSell;

    -- Calculate total cost of bought assets for the sold quantity
    SELECT @TotalBuyPrice = SUM(@SellQuantity * Price)
    FROM Transactions
    WHERE UserID = @UserID 
      AND PortfolioID = @PortfolioID 
      AND AssetID = @AssetID 
      AND TransactionType = 'Buy';

    -- Insert asset price update
    INSERT INTO AssetPrices (AssetName, Price, Date)
    VALUES (@AssetName, @SellPrice, GETDATE());

    -- Fetch commission rate for the broker
    SELECT @CommissionRate = CommissionRate
    FROM Brokers
    WHERE BrokerID = @BrokerID;

    -- Calculate commission fee
    SET @FeeAmount = @SellQuantity * @SellPrice * (@CommissionRate / 100);

    -- Insert commission fee record
    SET @TotalAmount = @SellPrice * @SellQuantity;

    INSERT INTO CommissionFees (UserID, PortfolioID, AssetID, BrokerID, FeeAmount, FeeDate, TotalAmount, CommissionPercent)
    VALUES (@UserID, @PortfolioID, @AssetID, @BrokerID, @FeeAmount, GETDATE(), @TotalAmount, @CommissionRate);

    -- Calculate total sell value and profit/loss
    SET @TotalSellValue = @SellQuantity * @SellPrice;
    SET @ProfitLoss = @TotalSellValue - @TotalBuyPrice;

    -- Retrieve current values for Performance table before updating
    SELECT @TotalVal = COALESCE(TotalValue, 0),
           @prevProfitLoss = COALESCE(ProfitLoss, 0)
    FROM Performance
    WHERE PortfolioID = @PortfolioID;

    -- Update the Performance table
    IF NOT EXISTS (SELECT 1 FROM Performance WHERE PortfolioID = @PortfolioID)
    BEGIN
        -- Insert new row if doesn't exist
        INSERT INTO Performance (PortfolioID, TotalValue, ProfitLoss, ROI, DateMeasured)
        VALUES (@PortfolioID, 
                @TotalSellValue - @TotalBuyPrice,
                @ProfitLoss,                     
                CASE WHEN @TotalSellValue - @TotalBuyPrice = 0 THEN 0
                     ELSE (@ProfitLoss / NULLIF(@TotalSellValue - @TotalBuyPrice, 0)) * 100
                END,
                GETDATE());
    END
    ELSE
    BEGIN
        -- Update existing row
        UPDATE Performance
        SET TotalValue = @TotalVal - @TotalBuyPrice + @TotalSellValue,
            ProfitLoss = @prevProfitLoss + @ProfitLoss,
            ROI = (ProfitLoss / NULLIF(TotalValue, 0)) * 100,
            DateMeasured = GETDATE()
        WHERE PortfolioID = @PortfolioID;
    END;

    -- Update asset quantity
    UPDATE Assets
    SET Quantity = Quantity - @SellQuantity,
        CurrentPrice = @SellPrice
    WHERE PortfolioID = @PortfolioID 
      AND AssetID = @AssetID;

    -- If profit is positive, insert tax payment
    IF @ProfitLoss > 0
    BEGIN
        SET @TaxAmount = @ProfitLoss * 0.1;

        INSERT INTO TaxPayments (UserID, TaxAmount, TaxType, PaymentDate)
        VALUES (@UserID, @TaxAmount, 'Capital Gains Tax', GETDATE());
    END;

    PRINT 'Stock sold successfully.';
END;
GO


select *from transactions
select *from CommissionFees
select *from Assets
select *from AssetPrices
select *from Performance
select *from TaxPayments

SELECT TaxType, sum(TaxAmount) as TotalAmount from TaxPayments 
group by TaxType