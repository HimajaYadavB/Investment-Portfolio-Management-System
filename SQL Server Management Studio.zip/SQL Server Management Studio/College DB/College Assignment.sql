--College DB SQL Questions , Paste Queries and Output screenshot 
--1. List the details of those instructors (IID, INAME, IDOJ, IPHNO, IDID) who teach  2 courses 
select *from instructor;
select *from course;

select iid, iname, idoj, iphno, idid from instructor where iid in(
	select iid from course group by iid having count(*)=2 )

--2. List the details of the instructors with more than 10 years of experience 
--(hint: use months_between single row function) 
select *from instructor where datediff(month,idoj, getdate())>10;

--3. List the details of the course taken by 4 students     
select *from course where cid in(select cid from enrolls group by cid having count(*)=4);

--4. How many students have taken up courses which has Programming Logic as a pre requisite  
select count(*) student_count from enrolls e join course c on e.cid=c.cid
where cprereq='proglogic';
 
--5. List the details of the instructor (iid,iname,iphno) and the name of the 
--departments (dname) they head 
select dname, d.dhid, iname, iphno
from department d join instructor i on d.dhid=i.iid
 

--6. List the courseID of those courses taken by students with more than 20 years of age. 
--Display unique values of courseID (CID) (Hint: use months_between scalar date function) 
select distinct cid from enrolls where sid in(select sid from student s where datediff(year, s.sdob, getdate())>20)
 

--7. List Cid,Cname,Cfees,Iid,Iname of the instructors taking up course like C, C++ and Java 
select cid, cname, cfees, c.iid, iname
from course c join instructor i on c.iid=i.iid
where cname in('c','c++','java');

 
--8. List cid,cname,cfees,iid,iname of the instructor who takes the costliest course 
select cid, cname, cfees, c.iid, iname
from course c join instructor i on c.iid=i.iid
where cfees=(select max(cfees)from course);
 

--9. List cid,cname,cfees,sid,sname of the students who have taken up the costliest course 
select c.cid, cname, cfees, e.sid, s.sname
from course c join enrolls e on e.cid=c.cid 
join student s on e.sid=s.sid
where cfees=(select max(cfees)from course);
 

--10. List the details (iid, iname , dname) of the instructor who heads the CS department 
select dname, d.dhid, iname from department d join instructor i on d.dhid=i.iid where dname='CS';

--11. List all the details of 2 most expensive course 
select top 2 *from course order by cfees desc;

--12. List the details of the instructors who belong to either CS or IS department 
select i.* from instructor i join department d 
on i.idid=d.did
where dname in('cs', 'is');

--13. List sid, sname and score of top 3 scorers(students) by descending order of score 
select top 3 s.sid, sname, score from student s join enrolls e on e.sid=s.sid order by score desc;
 
--14. List the cname of the course in which students have scored highest marks 
select cname from course where cid in (select top 1 cid from enrolls order by score desc);
 
--15. List all the details of the senior most Instructor 
select top 1 *from instructor order by idoj; 

--16. List the student name and  the name of the department which offers the courses they have taken  
select s.sname, dname
from student s join enrolls e on s.sid = e.sid 
join course c on c.cid = e.cid
join department d on c.did=d.did;


--17. List all the details of the department which offers maximum number of courses 
select top 1 count(*) cc from course group by did order by cc desc;
 
--18. List sid,sname,cid,cname,score of those students who have score >=80 marks 
select  s.sid, sname, score from student s join enrolls e on e.sid=s.sid where score>=80;
 
 --19. List sid,sname,cid,cname,score of those students who have taken up C++ course 
select  s.sid, sname, c.cid, score from student s join enrolls e on e.sid=s.sid 
join course c on c.cid=e.cid
where cname='c++';
 

--20. List coursename wise total fees collected so far. Sort the output by descending 
--order of totalfees 
select c.cname, sum(c.cfees) as total_fees from enrolls e join course c on e.cid=c.cid group by c.cname order by total_fees desc;

select cname, count(sid) * cfees as total_fee from course c join enrolls e on c.cid=e.cid group by cname, cfees order by total_fee desc;

--21. list course not taken by any student
select *from course where cid not in(select distinct cid from enrolls)
select *from course where cid in
(select cid from course
except
select distinct cid from enrolls)

--rank course in each dept based on cfees in desc order
select *, rank() over(partition by did order by cfees desc) 'rank'
from course