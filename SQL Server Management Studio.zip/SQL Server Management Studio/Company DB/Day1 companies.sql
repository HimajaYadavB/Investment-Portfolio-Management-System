--SELECT
select *from emp;

--PROJECTION
select ename, job, sal, deptno from emp;
select empno as Employee_Id, ename, job, sal, sal*12 as Annual_salary from emp;

--CONCATENATION of columns
select ename + ' WORKS AS '+job as Employee_Details from emp;

--NULL values
select empno, sal, comm, sal+comm as total_salary from emp;
select empno, sal, comm, sal+isnull(comm,10.01) as total_salary from emp;

select *from dept;

--selction/filtering of data-- using where clause- criteria based -- those records 
--whose col values satisfy the given criteria will be shown in the output 
select *from emp where sal>2000;

--relational/comparison operators
-- =,>,<, >=, <=, !=, <>, IN, BETWEEN, LIKE, IS NULL

--list all the employee who joined after 1981-12-31
select *from emp where hiredate>'1981-12-31';

--list all clerk
select *from emp where job='CLERK';
select *from emp where job='clerk';

--list all clerk in salesmen
select *from emp where job='clerk' or job='salesman';
select *from emp where job in('clerk', 'salesman');

--list all employees except clerk
select *from emp where job != 'clerk';

--between
select *from emp where sal between 2000 and 3000;

--list all emp who joined in the year 1981
select *from emp where hiredate between '1981-01-01' and '1981-12-31';

select *from emp where ename between 'a' and 'f';

select *from emp where ename like 's%'; --starts with s
select *from emp where ename like '%s'; --ends with s
select *from emp where ename like '%s%'; --contains s
select *from emp where ename like '%a%a%'; --contains 2a's
select *from emp where ename like '_a%'; --second char is a

--list all emp who joined in the year 1982
select *from emp where hiredate like '1982%';

--list all emp who joined in the month of december
select *from emp where hiredate like '%-12-%';

--list all emp who joined on 1st of any month
select *from emp where hiredate like '%01';

--is null
select *from emp where comm=null;  --doesnt null
select *from emp where comm is null;

--list all clerks from dept 10
select *from emp where job='clerk' and deptno=10;

--dept 10 or 20 with sal>2000
select *from emp where deptno in(10,20) and sal>2000;

--salesman who either earn comm or earn sal>1200
select *from emp where (sal>1200 or comm is not null) and job = 'salesman';

--all managers who earn sal>3000
select *from emp where job='manager' and sal>2500;

--clerks or manger who joined in 1981
select *from emp where job in('clerk', 'manager') and hiredate like '1981%';

--clerks who work in dept 10 or earn salary>1000
select *from emp where job='clerk' and (deptno=10 or sal>1000);


--Fetching N records, sorting the o/p
select top 4 *from emp;

--list the details of any 2 clerks
select top 2 *from emp where job='clerk';

--list job and salary of any 4 employee who joined in year 1981
select top 4 ename, job, sal from emp where hiredate like '1981%'; 

--order by
--all salesmen sorted by sal in descending order
select *from emp where job='salesman' order by sal desc;

--all salesmen sorted based on seniority
select *from emp where job='salesman' order by hiredate;

select *from emp order by ename;

--list the details of emp earning the highest salary
select top 1 *from emp order by sal desc;

--second highest sal
select *from emp order by sal desc offset 1 rows fetch next 4 rows only;

--apply order by on alias name also
select empno, ename empname from emp order by empname;

--sort by 5th col
select *from emp order by 5 desc;

select ename, empno, job from emp order by 3;

select *from emp order by job, hiredate desc;

select *from emp order by job, sal;