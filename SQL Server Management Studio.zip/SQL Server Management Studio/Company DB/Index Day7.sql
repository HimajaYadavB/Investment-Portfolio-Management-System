use HumanResource;
select * into empdet from employees;

select *from empdet;
select *from empdet where employee_id=121;

select *from employees where employee_id=121;

select *from employees where employee_id in(121,100);

select *from employees where department_id=8;

create nonclustered index department_id_ix on employees(department_id)

select *from employees where department_id=8;

select department_id from employees;   --nonclustered index scan
select department_id from employees where department_id=8;   --non clustered index seek

select department_id from employees where department_id in(8,9);

select employee_id, department_id from employees;  --non clustered scan

select employee_id, department_id from employees where employee_id=108 and department_id=8;

--composite/multicolumn index
drop index employees.DEPTID_FNAME_IX;
CREATE NONCLUSTERED INDEX DEPTID_FNAME_IX ON DBO.EMPLOYEES(DEPARTMENT_ID, FIRST_NAME);
 
SELECT FIRST_NAME , DEPARTMENT_ID FROM EMPLOYEES WHERE DEPARTMENT_ID=8;

SELECT EMPLOYEE_ID,FIRST_NAME , DEPARTMENT_ID FROM EMPLOYEES WHERE DEPARTMENT_ID=8;
 
--FUNCTION BASED INDEX



