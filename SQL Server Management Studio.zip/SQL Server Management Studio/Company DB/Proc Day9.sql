--extended sp
exec xp_logininfo 'BSG\BheemanathamH'

--user defined procedures
create procedure empdept10
as
select *from emp where DEPTNO=10;

exec empdept10

--list the details of the emp from a given deptno
create or alter proc selempdept @dno int=10
as 
begin
	select *from emp where deptno=@dno;
end

exec selempdept;
exec selempdept 20
exec selempdept @dno=10;

-- GET THE SAL OF A GIVEN EMPNO IF THE SAL<3000 ; 
--RAISE A RUNTIME ERROR (MESSAGE 'TOO LOW SAL TO APPROVE LOAN' ; 
--ELSE PRINT 'LOAN WOULD BE PROCESSED SOON' 
--empno 7369(low), 7839(ok), 14(not found)
create or alter proc emploan @empno int=14
as
begin 
begin try
declare @sal int
select @sal = sal from emp where empno=@empno
if @sal is null
begin
	print 'emp not found'
	raiserror('emp not found',16,1)
end
else if @sal<3000
	raiserror(@sal+'TOO LOW SAL TO APPROVE LOAN',16,1)
else print 'LOAN WOULD BE PROCESSED SOON'
end try
begin catch
select error_message() as errormsg
end catch
end

exec emploan;
exec emploan 7369;
exec emploan 7839;
exec emploan 14;

--to update the emp with the deptno
create or alter proc upempnydeptno @dno int=30
as
begin
update emp set sal=sal+100 where DEPTNO=@dno;
select @@ROWCOUNT
end

exec upempnydeptno;
select *from emp order by deptno desc;
exec upempnydeptno 99;


--get headcount from a given deptno
create or alter proc getempctbydept @dno INT, @ct INT OUTPUT
as
begin
	declare @x int=10, @y int;
	select @ct=count(*) from emp where deptno=@dno;
	set @y=@x*2;
	select @y;
end

declare @res int;
exec getempctbydept 30, @res output;
select @res


--
create or alter proc insertcourse
	@crid numeric(3), @crname varchar(10), @crfees numeric(7,2)
as
begin
begin try
begin transaction
	insert into course(cid, cname, cfees) values (@crid, @crname, @crfees);
commit transaction
end try
begin catch
rollback transaction
	select ERROR_MESSAGE() as err_msg,
	ERROR_SEVERITY() as err_severity,
	ERROR_STATE() as err_state
end catch
end

exec insertcourse 111, 'DBA', 4000 --successful
exec insertcourse 112, 'DBA', 4000  --error, violation of unique key constraint on cname
exec insertcourse 113, 'MySQLDBA', 4000  --successful
exec insertcourse 112, 'MySQLDBAA', 4000   --successful


------
use HumanResource;
create or alter procedure EmpPerfRpt
as
begin
	create table #EmpSalSummary (
		did int, 
		dname nvarchar(100),
		TSal decimal(18,2),
		Empcount int
	);
	--insert intermediate data into the temp table
	insert into #EmpSalSummary(did, dname, TSal, Empcount) 
	select e.department_id, department_name, sum(salary), count(employee_id)
	from employees e join departments d on e.department_id=d.department_id
	group by e.department_id, department_name;
	--final report query using temp table
	select dname, Tsal, Empcount, Tsal/Empcount as avgsal
	from #EmpSalSummary

	--drop temp table
	drop table #EmpSalSummary;
end

exec EmpPerfRpt;


-----Functions
create or alter function addtwonum(@a int, @b int) returns int
as
begin
return @a+@b
end
go
select dbo.addtwonum(10,20), abs(-10), upper('Himaja');

declare @y int;
begin
set @y=dbo.addtwonum(20,20);
select @y
end

--table type function
CREATE FUNCTION GETEMPBYJOB (@JOB VARCHAR(10)) RETURNS TABLE
AS 
RETURN (SELECT ENAME,JOB FROM EMP WHERE JOB=@JOB);
go

select *from dbo.GETEMPBYJOB('SALESMAN')
select count(*) from dbo.GETEMPBYJOB('SALESMAN')
select count(*) from dbo.GETEMPBYJOB('SALESMA')
select *from dbo.GETEMPBYJOB('CLERK')


--MULTIVALUED TABLE FUNCTION 
CREATE FUNCTION FNGETMULEMPLOYEE()
RETURNS @EMP TABLE 
(
	EMPNO INT,
	ENAME VARCHAR(50),
	SALARY INT 
)
AS 
BEGIN 
	INSERT INTO @EMP SELECT E.EMPNO, E.ENAME, E.SAL FROM EMP E;
	UPDATE @EMP SET SALARY=25000 WHERE EMPNO = 7902;
	RETURN
END;

select *from DBO.FNGETMULEMPLOYEE();

--a udf to take a numeric value and return a numeric values
create or alter function upcomm(@a int) returns int
as
begin
declare @x int
if @a between 500 and 1000
	set @x=100
else if @a between 1001 and 2000
	set @x=200
else
	set @x=300
return @x
end
go
select dbo.upcomm(2000)
select empno, ename, job, sal,comm, dbo.upcomm(sal) from EMP;
update emp set comm=dbo.upcomm(sal);
select empno, ename, job, sal,comm, dbo.upcomm(sal) from EMP;

--triggers
create trigger trdept on dept for insert, update, delete
as
begin
if datepart(WEEKDAY, GETDATE())=5
begin
	print 'DML operations are restricted on friday'
	rollback transaction;
end
end

insert into dept(DEPTNO, DNAME) values(13,'abcde')

disable trigger trdept on dept;
enable trigger trdept on dept;
drop trigger trdept

--exists
select *from emp where exists(select empno from emp where deptno=20)

--back to triggers
select *from dept;
select *into log_dept from dept where deptno=99
select *from log_dept

--create trigger on dept table for insert
create trigger dept_ins on dept after insert as
insert into log_dept select *from inserted

insert into dept values(50,'sw','mumbai',7698);

--create trigger on dept table for delete
create trigger dept_del on dept after delete as
insert into log_dept select *from deleted

delete from DEPT where deptno=50;

rollback tran
set implicit_transactions on;
delete from DEPT where deptno=40;
select *from dept
select *from log_dept
rollback transaction


--instead of trigger--tables/views will be invoked instead of an I, U, D operations
select *from course
delete from course where cid in(1,111);
select *from course
create view coursevw as select cname, cfees from course;
select *from coursevw;

create trigger inscw on coursevw instead of insert as
begin
	declare @x int
	select @x=max(cid) from course;
	insert into course select @x+1, upper(cname), cfees from inserted
end;

insert into coursevw values('Python',4000);
select *from coursevw;
select *from course;

--ddl triggers
create trigger t1 on database for drop_table, alter_table
as
print 'you cant drop or alter table'
rollback;

drop table SALGRADE

disable trigger t1 on company