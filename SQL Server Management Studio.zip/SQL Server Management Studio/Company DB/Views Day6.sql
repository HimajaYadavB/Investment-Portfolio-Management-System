--views
create view empv1 as select *from emp where sal>2000;
select *from empv1;

sp_helptext empv1;

select *from emp;
insert into empv1(empno, ename, job, hiredate,sal) values(1,'himaja','analyst',null,5000)
delete from emp where empno=1;
update empv1 set sal=1500 where ename='ford';
select *from empv1;

alter view empv1 as select *from emp where sal>2000 with check option;
update empv1 set sal=5000 where ename='jones';

insert into empv1(empno, ename, job, hiredate,sal) values(1,'himaja','analyst',null,1500)

update emp set ename=upper(ename)

--ENCRYPTED VIEWS ->DEFINITION IS NOT SHOWN
CREATE VIEW DEPTVIEW
WITH ENCRYPTION AS 
	SELECT * FROM DEPT;
 
SP_HELPTEXT 'DEPTVIEW';--SAYS: The text for object 'DEPTVIEW' is encrypted.
 
ALTER VIEW DEPTVIEW
AS 
	SELECT * FROM DEPT;
 
SP_HELPTEXT 'DEPTVIEW';--WORKS AGAIN

create view empsalary 
as select empno, ename, sal, sal+isnull(comm,0) totalsal from emp;
select *from empsalary

insert into empsalary values(1111, 'himaja', 3000, 4000); --failed
update empsalary set sal=4000 where empno=7782; --successful



create view empdeptvw as SELECT e.*,d.dname FROM emp e JOIN dept d ON e.deptno=d.deptno;
select *from empdeptvw;
update empdeptvw set dname='software' where dname = 'sales'


sp_depends 'emp'
alter view empdashboard with schemabinding as
select deptno, min(sal) msal, max(sal) hsal, avg(sal) asal from dbo.emp 
where deptno is not null
group by deptno;

select *from empdashboard;

alter table emp drop column sal; 
--fails because empdashboard is dependent on the column sal of emp

select *from dept;
create view deptvw as select dname, loc from dept;
insert into deptvw values('it','pune') --fails because we cannot have null value into the deptno primary key

alter table dept add dhead numeric(4);
alter table dept drop column dhead
drop view deptvw

create view deptvw as select *from dept;
select *from deptvw

alter table dept add dhead numeric(4);
select *from dept;
select *from deptvw;

sp_refreshview deptvw;

--synonyms
select *from emp_details_hr

--command line synonym creation
create synonym [dbo].[emp_details_hr1] for
[BR-2252380165].[HumanResource].[dbo].[employees]

select *from emp_details_hr1



