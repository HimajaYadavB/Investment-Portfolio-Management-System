--
create table course(
	cid numeric(3) constraint cid_ph primary key,
	cname varchar(10) constraint cn_nn not null,
	cfees numeric(7,2) constraint cf_ch check(cfees>2000),
	constraint cn_uq unique(cname)
);

create table student(
	sid numeric(4) primary key,
	sname varchar(10) not null,
	sob date,
	sadd varchar(20) default 'Pune',
	scid numeric(3) constraint scid_fk references course(cid)
);

ALTER TABLE student
DROP CONSTRAINT scid_fk;  -- First, drop the existing FK

ALTER TABLE student
ADD CONSTRAINT scid_fk FOREIGN KEY (scid)
REFERENCES course (cid) ON DELETE SET NULL;


--OR
/*alter table student add constraint scid_fk 
foreign key(scid) references course(cid) on delete set null;*/

--OR
/*create table student(
	sid numeric(4) primary key,
	sname varchar(10) not null,
	sob date,
	sadd varchar(20) default 'Pune',
	scid numeric(3),
	constraint scid_fk foreign key(scid) references course(cid)
);*/

alter table student add sphno numeric(10);
alter table student add unique(sphno);
alter table student drop constraint[UQ__student__5D62CE33C5BD1404]
alter table student drop constraint[UQ__student__5D62CE331E720AD8]
alter table student drop column sphno;
alter table student alter column sadd varchar(30);

alter table dept add constraint dp_pk primary key(deptno);
alter table emp add constraint em_pk primary key(empno);
alter table emp add constraint mg_fk foreign key(mgr) references emp(empno);
alter table emp add constraint dp_fk foreign key(deptno) references dept(deptno);

--create a table like an existing table(copy the structure(colname, datatype, size))
select *into copyemp from emp;
select *from copyemp;
drop table copyemp;

select empno, ename, deptno, sal into copyemp from emp where deptno=20;

select empno, ename empname, deptno, sal empsall into copyemp from emp where deptno=20;

--copy the structure, no data
select *into copyemp from emp where 1=2;
insert into copyemp select *from emp where sal>2000;

select empno, ename into cpy from emp;
select *from cpy;