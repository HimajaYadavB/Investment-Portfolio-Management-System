create table emp1 (eid numeric unique, en varchar(50));
drop table sall;
create table sall(eid numeric, sal numeric, foreign key(eid) references emp1(eid));

--correlated subqueries
--list details of emp who earn sal>avg(sal) of their respective department
select *from emp e1 where sal>(
	select avg(sal)from emp e2 where e1.DEPTNO=e2.DEPTNO group by deptno);
	--here we need not use group by because by default when we give the subquery criteria, 
	--it acts like a group by
select deptno, avg(sal) from emp group by deptno;

--inline view
select e.* from emp e join (select deptno, avg(sal) asal from emp group by deptno) x
on e.deptno=x.deptno and e.sal>asal;

--CTE, with
with dep as(select deptno, avg(sal) asal from emp group by deptno),
j as (select job, avg(sal) aa from emp group by job)
select e.* from emp e join dep x
on e.deptno=x.deptno 
join j on e.job=j.job and sal>asal and sal>aa;

--Set operated queries union all, union, intersect, except
select empno, ename, job, sal from emp where sal>2000
except
select empno, ename, job, sal from emp where job='manager'

--hct group by dept and job
select deptno, job, count(*)from emp 
group by deptno, job
order by deptno,job;

--rollup
select deptno, job, count(*)from emp 
group by rollup(deptno, job)
order by deptno,job;

--cube
select deptno, job, count(*), grouping(deptno), grouping(job) from emp 
group by cube(deptno, job)
order by deptno,job;

--grouping sets
select deptno, job, count(*) hct from emp
group by
grouping sets((deptno),(job),(deptno,job)) order by deptno;

--comp between grouping sets and rollup
select deptno,job, count(*) hct from emp
group by
grouping sets((deptno),(job)) order by deptno;

select deptno,job, count(*)from emp 
group by rollup(job,deptno)
order by deptno;

select deptno,job, count(*)from emp 
group by rollup(deptno,job)
order by job;

--analytical functions/window functions
select empno, ename, deptno, sal, sum(sal) over() from emp order by deptno;

select empno, ename, deptno, sal, job,sum(sal) over(partition by deptno,job) from emp order by deptno;

--arrange the emp based on seniority in each dept(number the emp records)
select empno, ename, sal, deptno, hiredate,
row_number() over(partition by deptno order by hiredate) as elist from emp
order by deptno;

--list senior members in each dept
select *from(select empno, ename, sal, deptno, hiredate,
row_number() over(partition by deptno order by hiredate) as elist from emp) x
where elist=1;

select empno, ename, sal, deptno, hiredate,
row_number() over(partition by deptno order by sal desc) as elist from emp
order by deptno;

--rank
select empno, ename, sal, deptno, hiredate,
rank() over(partition by deptno order by sal desc) as elist from emp
order by deptno;

--dense rank
select empno, ename, sal, deptno, hiredate,
dense_rank() over(partition by deptno order by sal desc) as elist from emp
order by deptno;

--lead and lag
select empno, ename, deptno, sal,
lead(sal,2) over(partition by deptno order by sal) as higher_sal,
lag(sal,1) over(partition by deptno order by sal) as lower_sal from emp;
