--joins
--list empno, ename, job, deptno, dname
select empno, ename, job, e.deptno, dname from emp e
join dept d
on e.DEPTNO=d.DEPTNO;

--list empno, ename, job, deptno, dname from sales department
select empno, ename, job, e.deptno, dname from emp e
join dept d
on e.DEPTNO=d.DEPTNO
where dname='sales';

--costly because the all the records are fetched and then the and condition is applied
--whereas if we are using WHERE clause, the table is first filtered and then join is applied
select empno, ename, job, e.deptno, dname from emp e
join dept d
on e.DEPTNO=d.DEPTNO
and dname='sales';

select *from SALGRADE;
--list empno, ename, job, sal, deptno, grade
select empno, ename, job, sal, deptno, grade 
from emp e join salgrade s
on e.sal between s.losal and s.hisal;

--list empno, ename, job, sal, deptno, grade of those emp with sal>2000
select empno, ename, job, sal, deptno, grade 
from emp e join salgrade s
on e.sal between s.losal and s.hisal
where sal>2000;

--list empno, ename, deptno, dname, sal, grade
select empno, ename, e.deptno, dname, sal, grade
from emp e join dept d on e.DEPTNO = d.DEPTNO 
join SALGRADE s on e.sal between s.LOSAL and s.HISAL;

--list emp details with all the departments
select empno, ename, job, d.deptno, dname 
from emp e right join dept d on e.DEPTNO=d.DEPTNO;

--list every empno, ename, sal and respective grade
select empno, ename, job, sal, deptno, isnull(grade,0) 
from emp e left join salgrade s
on e.sal between s.losal and s.hisal;

--list every empno, ename, sal, deptno, dname and respective grade
select empno, ename, job, sal,  isnull(grade,0) as grade, e.deptno, dname
from emp e left join salgrade s on e.sal between s.losal and s.hisal
right join dept d on d.deptno=e.deptno;

--cross join
select ename, dname from emp cross join dept;

select e.ename employee_name, m.ename manager_name from emp e
left join emp m on e.mgr=m.EMPNO;

select e.ename +' REPORTS TO '+ isnull(m.ename,'NONE') from emp e
left join emp m on e.mgr=m.EMPNO;

--list empno, ename, deptno, dname, sal, grade of those emp who work in chicago
--and earn sal>2000
select empno, ename, d.deptno, dname, sal, grade 
from emp e join dept d on e.DEPTNO=d.DEPTNO
join SALGRADE s on e.SAL between s.LOSAL and s.HISAL
where LOC='chicago' and sal>2000;

--list dname hct(count of emp in each dept) -- sort the output in desc order of hct
select dname, count(*) hct
from emp e right join dept d on e.DEPTNO=d.DEPTNO
group by dname
order by hct desc;

--list loc, min(sal), max(sal) only if avg(sal)>1000
select loc, (ISNULL(min(sal),0)), (ISNULL(max(sal),0))
from emp e right join dept d on e.DEPTNO=d.DEPTNO
group by loc
having avg(sal)>1000;


--nested query/subquery
--list all emp who are junior to ford
select *from emp 
where hiredate>(select top 1 hiredate from emp where ename='ford');

--list al emp who earn sal>max(sal) paid for clerks
select *from emp where sal>(select max(sal) from emp where job='clerk');

--list the details of emp who work in the research dept
select *from emp where deptno = (
	select deptno from dept where dname='research') 
order by sal desc;

--list details of emp who work with ford
select *from emp where DEPTNO =(
	select deptno from emp where ename='ford')

--list the details of emp who work with ford and report to ford's manager
select *from emp where deptno=(select deptno from emp where ename='ford') and
mgr=(select mgr from emp where ename='ford') and ename!='ford'

--list the details of dept which has more than 3 employees in it
select *from dept where deptno in(
	select deptno from emp group by deptno having count(empno)>3);

--list details of emp who work in dept with headcount>3
select *from emp where deptno in(
	select deptno from emp group by deptno having count(empno)>3);

--list details of emp who earn sal>avg(sal)
select *from emp where sal>(select avg(sal)from emp);

--list details of emp who earn sal>avg(sal) of any of the dept
select *from emp where sal>any(select avg(sal)from emp group by deptno);

--list details of emp who earn sal>avg(sal) of all the dept
select *from emp where sal>all(select avg(sal)from emp group by deptno);
