--add 2nos
declare @x int, @y int, @z int, @a date, @b varchar(10);
begin
	set @x=100;
	set @y=200;
	select @z = @x+@y;
	select @a=getdate(), @b='Himaja';
	Print 'The sum is: '+convert(char(10),@z);
	print convert(char(15),@a)+' '+@b;
end;

if datename(weekday, getdate()) in ('Saturday','Sunday')
begin
	select 'Weekend'
	print 'this is weekend'
end
else
begin
	print 'this is weekday'
	select 'Weekday'
end

if exists(select ename from emp where ename='scoott')
begin
	print 'found scott'
end
else
if exists(select ename from emp where ename='smiith')
begin
	print 'found smmith'
end
else
print 'no one found'

--nested if
declare @num int
set @num = 50;

if @num>100
	print 'num is large';
else
begin
	if @num<10
		print 'num is small'
	else
		print 'num is medium'
end
go