--DML --insert, upate, delete, merge
select *from course;
insert into course values(101, 'SQL', 4000);
insert into course values(102, 'MySQL', 3000);
insert into course values(103, 'PostgreSQL', 2500);
insert into course values(104, 'MSSQL', 2500);
insert into course values(105, 'Java', 5500);

select *from student
delete from student where sid=1
alter table student drop constraint [UQ__student__5D62CE3308022E29]
alter table student drop column sphno;

insert into student values (1, 'Ravi', '2000-12-23',default,101);
insert into student(sid, sname, scid) values (2, 'Guru',102);
insert into student(sid, sname, scid) values (3, 'Jack',null);
insert into student(sid, sname, scid) values (4, 'King',105);
insert into student(sid, sname, scid) values (5, 'Jim',102);

select *into copystudent from student where 1=10;
insert into copystudent select *from student where 1=1;

select *into copystudent1 from student;

insert into student values (6, 'Raghu', '2000-12-23','Chennai',101);

--Update
select *from course;
select *from student;
update student set sob='2001-06-12' where sid=2;

--update dob of student king to the hiredate on emp ford
update student set sob=(select hiredate from emp where ename='ford') where sname='king';

update student set sob='2003-11-17', sadd='Bangalore' where sname='jim'

update student set sob='2003-11-17', sadd='Bangalore' where sname='ram' or sob is null;


--delete
begin transaction
select *from emp;
update emp set sal=8000;
select *from emp;
rollback transaction;
select *from emp;
update emp set sal=8000 where ename='king';

--live lock demonstration
begin transaction
update dept set dname=lower(dname);
commit transaction


select *from dept

--implicit transactions
set implicit_transactions off;
update dept set loc=lower(loc);
select *from dept;
rollback;
select *from dept;
update dept set dname=upper(dname);
update dept set dname=lower(dname);
update emp set ename=lower(ename);
rollback transaction;
select *from dept;
select *from emp;


set implicit_transactions on;
delete from student;
select *from student;
rollback;
select *from student;
delete from student where scid is null;
commit;
select *from student;
delete from course where cid=102;
rollback;
select *from course;


--merge -- upset -- update/delete/insert based on select
--merge the target table with the source table

/*merge into target(tab1)
using source (tab1) on criteria
when matched then 
--
--
when not matched then
--
-- */
select *from student;

set implicit_transactions off;

create table SMarks(
	StID numeric(4) references student(sid),
	Stmarks integer
);

insert into SMarks values(1,230)
insert into SMarks values(2,255)

insert into SMarks values(5,235)


delete from SMarks where stid in (1,2,5,4,6)

select *from smarks;

merge smarks stm
using(select sid, sname from student) sd
on (stm.stid = sd.sid) 
when matched and stm.stmarks>250 then delete
when matched then 
update set stm.stmarks=stm.stmarks+25
when not matched then 
insert (stid, stmarks) values (sd.sid, 25);