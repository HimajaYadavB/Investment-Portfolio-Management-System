--scalar functions/single row function

--date
select GETDATE(), 10+10, 20/2

--character -- lower, upper, left, right, replace, reverse,concat, substring, charindex, len
select upper('broadridge')
select lower('HELO')
select lower(ename) from emp;

select left('himaja', 3)
select right('himaja', 3)

select SUBSTRING('himaja',2,3)

select REPLACE('himaja', 'a', '$')

select CHARINDEX('ax', 'himaja')
select REVERSE('himaja')


select CHARINDEX('.','himaja.bheemanatham@broadridge.com') as ci
select left('himaja.bheemanatham@broadridge.com', CHARINDEX('.','himaja.bheemanatham@broadridge.com')-1),
SUBSTRING('himaja.bheemanatham@broadridge.com',CHARINDEX('.','himaja.bheemanatham@broadridge.com')+1, CHARINDEX('@','himaja.bheemanatham@broadridge.com')-CHARINDEX('.','himaja.bheemanatham@broadridge.com')-1)


--numeric
select ABS(-10), SIGN(-200),SIGN(200), POWER(2,3), SQRT(64), ROUND(123.87986986,2), 
FLOOR(1.999), CEILING(1.0002)

--date
select dateadd(month,2,getdate()), dateadd(year,2,getdate()), dateadd(day,1,getdate())

select dateadd(day,2,'11-16-2003')
select hiredate, dateadd(month,2,hiredate) from emp;

--month,year,day
select month(getdate()), year(getdate()), day(getdate())

select datediff(year,hiredate, getdate()) from emp;
select datediff(month,hiredate, getdate()) from emp;
select datediff(day,hiredate, getdate()) from emp;

select DATENAME(month, getdate()),DATENAME(year, getdate()),DATENAME(day, getdate()),
DATENAME(DAYOFYEAR, getdate()), DATENAME(week, getdate()), DATENAME(WEEKDAY, getdate()),
DATENAME(dw, getdate()), DATENAME(QUARTER, getdate()),getdate(), DATENAME(hour, getdate()), 
DATENAME(MINUTE, getdate()), DATENAME(second, getdate())

--list all emp who joined on a monday
select *from emp where DATENAME(WEEKDAY,hiredate)='Monday';
select *from emp where datepart(WEEKDAY,hiredate)=2

--list all emp who joined on 3rd or 4th quarter
select *from EMP where DATENAME(quarter, hiredate)>=3;

--all emp who joined after 20th of any month
select *from emp where datename(day,hiredate)>20;
select *from emp where day(hiredate)>20;

--all emp who joined in jan
select *from emp where datename(month,hiredate)='January';
select *from emp where month(hiredate)=1;

--all emp who joined in 1982
select *from emp where datename(year,hiredate)='1982';
select *from emp where year(hiredate)=1982;

--all emp who have >42 year of exp
select *from emp where DATEDIFF(year, hiredate, getdate())>42;

--all emp who have >5 character in ename
select *from emp where len(ename)>5;

--all emp who earn sal in multiples of 4
select *from emp where sal%4=0;

--round
select round(678.878,-1), round(674.679,-1), round(623.767,-2), round(568,-3), round(5122.231,-3);

select datepart(day,getdate()), datepart(week,getdate()), datepart(weekday,getdate()),
datepart(QUARTER,getdate())

--cast
select cast(14.66 as int)
select cast(14.66 as float)
select cast('11-16-2003' as datetime)

--convert(datatype size, exp, format)
select convert (int,14.85)
select convert(float, '17.77')
select convert(datetime, '2003-11-16')

select convert(varchar, getdate(), 100);
select convert(varchar, getdate(), 101);
select convert(varchar, getdate(), 102);
select convert(varchar, getdate(), 103);
select convert(varchar, getdate(), 104);

--generic -isnull, case
select empno, ename, sal, job, comm, isnull(convert(varchar,comm),'N/A') newcomm from emp;

--case
select empno, ename, deptno, 
case deptno
when 10 then 'A'
when 20 then 'B'
else 'X' end as empgrade from emp;

--extended case
select empno, ename, deptno,sal, job,
case 
when sal between 1000 and 2000 and job='clerk' then 'A'
when sal between 500 and 1000 then 'B'
when job='salesman' then 'S'
else 'X' end as empgrade from emp;

--aggregate ffunctions

select sum(sal), min(sal), max(sal) from emp;
select ename, sum(sal) from emp;

--total sal paid from emp in dept 20,30
select sum(sal) from emp where DEPTNO in (20,30);

--total sal paid for emp who earn comm
select sum(sal) from emp where comm is not null;

select *from emp;

--get headcount of clerk
select count(*) from emp where job='clerk'

--no of salesman earn comm
select count(comm) from emp where job='salesman'

--no of salesman earn sal>1500
select count(*) from emp where job='salesman' and sal>1500;

--headcount of emp in each job
select job, count(*) from emp group by job;

--get min,max sal of emp in each dept excluding clerks
select min(sal) mini, max(sal) from emp where job!='clerk' group by DEPTNO;

--get jobwise headcount excluding emp who earn sal<1000
select job, count(*) cc from emp 
where sal>=1000 
group by job
order by cc desc;

--get deptwise jobwise headcount
select deptno, job, count(*) cc from emp
group by deptno,job
order by deptno;

--get jobwise headcount excluding emp who earn sal<1000 and count>2
select job, count(*) cc from emp 
where sal>=1000
group by job
having count(*)>2
order by cc desc;

--get deptwise min(sal), max(sal) excluding emp who do not have a manager
select deptno, min(sal), max(sal) from emp
where mgr is not null
group by deptno;

--get deptwise min(sal), max(sal) excluding emp who do not have a manager
--only if min(sal) > 1000
select deptno, min(sal), max(sal) from emp
where mgr is not null
group by deptno
having min(sal)>1000;

--get mgrwise count of reportees
select mgr, count(*) from emp
where mgr is not null
group by mgr;

--yearly count of emp joining the company
select year(hiredate) yoj, count(*) hct from emp
group by year(hiredate)
order by yoj;

--monthly count of emp joining the company display the o/p in the order of calender months
select datename(month,hiredate) moj, count(*) hct  from emp
group by datename(month,hiredate),MONTH(hiredate)
order by MONTH(hiredate);

--get headcount of managers from each department
select deptno, count(*) total from emp
where job='manager' 
group by deptno

--dept wise avg salary only if it is more than 1500
select deptno, avg(sal)from emp
where sal>1500
group by DEPTNO