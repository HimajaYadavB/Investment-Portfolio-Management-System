--add 2nos
declare @x int, @y int, @z int, @a date, @b varchar(10);
begin
	set @x=100;
	set @y=200;
	select @z = @x+@y;
	select @a=getdate(), @b='Himaja';
	Print 'The sum is: '+convert(char(10),@z);
	print convert(char(15),@a)+' '+@b;
end;
---------------------------------------------------------
if datename(weekday, getdate()) in ('Saturday','Sunday')
begin
	select 'Weekend'
	print 'this is weekend'
end
else
begin
	print 'this is weekday'
	select 'Weekday'
end
----------------------------------------------------------
if exists(select ename from emp where ename='scoott')
begin
	print 'found scott'
end
else
if exists(select ename from emp where ename='smiith')
begin
	print 'found smmith'
end
else
print 'no one found'
----------------------------------------------------------
--nested if
declare @num int
set @num = 50;
if @num>100
	print 'num is large';
else
begin
	if @num<10
		print 'num is small'
	else
		print 'num is medium'
end
go
----------------------------------------------------------
--while
declare @count int
set @count=0;
while @count<3
begin
	print 'hello world'
	set @count = @count+1
end
----------------------------------------------------------
--break and continue
--declare @count int
--set @count=0;
declare @count int =0;
while @count<10
begin
	print 'hello world '+convert(char(2),@count)
	set @count = @count+1
	if @count>=5
		break
	else
		continue
end
print 'out of while'
----------------------------------------------------------
--case
declare @x int
set @x=10;
select case @x
when 10 then 'A'
when 20 then 'B'
else 'X' end
go
--------------------------------
declare @x int =11;
begin transaction
if @x<10
begin 
	update emp set sal=sal+100
	select *from emp
end
else
begin
	update dept set loc=lower(loc);
	select *from dept;
end
rollback transaction

select *from dept;

--write a tsql for given employee id update the commission to be 10% of the salary
declare @eno int = 7902
update emp set comm=sal*0.1 where empno=@eno
select *from emp;

--cursors
declare @id int, @name varchar(50), @salary int
declare cur_emp cursor static for select empno, ename, sal from emp;
open cur_emp
print convert(varchar(50),@@cursor_rows)
if @@CURSOR_ROWS>0
begin
	fetch next from cur_emp into @id, @name, @salary
	while @@FETCH_STATUS=0
	begin 
		print 'ID:'+convert(varchar(20),@id)+', Name:'+@name+', Salary:'+convert(varchar(20),@salary)
		fetch next from cur_emp into @id, @name, @salary
	end
end
close cur_emp
deallocate cur_emp

--based on sal of emp update the commission
set nocount on
declare @eno int, @sal int
declare c1 cursor for select empno, sal from emp
open c1
fetch next from c1 into @eno, @sal
while @@FETCH_STATUS=0
begin
	if @sal>500 and @sal<2000
	update emp set comm=150 where empno=@eno;
	else if @sal>=2000 and @sal<=3000
	update emp set comm=250 where empno=@eno;
	else
	update emp set comm=350 where empno=@eno;
	fetch next from c1 into @eno, @sal
end
close c1
deallocate c1
set nocount off;
select *from emp;

--based on the job of emp in emp table we need to update the bonus col in empbonus table
select empno, ename, sal, sal+isnull(comm,0) ebonus into empbonus from emp;
select *from empbonus;

declare @eno int, @job varchar(50)
declare c1 cursor for select empno, job from emp
open c1
fetch next from c1 into @eno, @job
while @@FETCH_STATUS=0
begin
	if @job='clerk' update empbonus set ebonus=100 where empno=@eno;
	else if @job='salesman' update empbonus set ebonus=200 where empno=@eno;
	else if @job='analysr' update empbonus set ebonus=300 where empno=@eno;
	else update empbonus set ebonus=400 where empno=@eno;
	fetch next from c1 into @eno, @job
end
close c1
deallocate c1

select *from empbonus;

declare @x int;
set @x=1/0;
insert into dept values(55,'Training','Mysore',9999)

begin try
declare @x int;
insert into dept values(54,'Training','Mysore',9999)
set @x=1/0;
insert into dept values(55,'abc','pune',9988)  --statement never gets executed
end try
begin catch
print 'error detected'
end catch

select *from dept;

--with begin and rollback transaction
begin try
begin transaction
declare @x int;
insert into dept values(56,'Training','Mysore',9999)
set @x=1/0;
insert into dept values(57,'abc','pune',9988)  --statement never gets executed
commit transaction
end try
begin catch
rollback transaction
print 'error detected'
end catch

begin try
--inserting duplicate pk
insert into course values(101,'unix',4000);
end try
begin catch
select 
	ERROR_NUMBER() 'error message', 
	ERROR_SEVERITY() 'error severity', 
	ERROR_STATE() 'error state', 
	ERROR_PROCEDURE() 'error proc', 
	ERROR_LINE() 'error line',
	ERROR_MESSAGE() 'error message'
end catch

set implicit_transactions on;
dbcc useroptions
set implicit_transactions off;

begin try
declare @myint int;
set @myint = 1/0;
end try
begin catch
declare @errormsg nvarchar(4000);
select @errormsg=ERROR_MESSAGE()
print convert(char(1000),@errormsg);
--raiserror('some errorr', 16,1);
raiserror(50010,16,1)
end catch

--to add the custom error number with custom error message
use master
exec sp_addmessage 50010, 16, 'custom error message';
exec drop_message

begin try
begin transaction
update emp set sal=sal+100 where deptno=20;
if @@ROWCOUNT>3
raiserror(50010,17,1)
end try
begin catch
rollback transaction
select 
	ERROR_NUMBER() 'error message', 
	ERROR_SEVERITY() 'error severity', 
	ERROR_STATE() 'error state', 
	ERROR_PROCEDURE() 'error proc', 
	ERROR_LINE() 'error line',
	ERROR_MESSAGE() 'error message'
end catch

--temp tables and table type variables
CREATE TABLE #T(s varchar(128))
DECLARE @T TABLE (S VARCHAR(128))
INSERT INTO #T SELECT 'OLD VALUE #'
INSERT INTO @T SELECT 'OLD VALUE @'
BEGIN TRANSACTION 
	UPDATE #T SET S='NEW VALUE #'
	UPDATE @T SET S='NEW VALUE @'
ROLLBACK TRANSACTION --AFFECT THE TABLE BUT NOT THE TABLE VARIABLE
SELECT * FROM #T
SELECT * FROM @T