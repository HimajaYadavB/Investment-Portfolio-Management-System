create table empleave(
	leave_id int primary key,
	employee_id int foreign key references employees,
	leavedate date,
	reason varchar(100) check(reason in('sick','vacation','maternity','paternity'))
);
create table empleave1(
	leave_id int primary key identity(1,1),
	employee_id int foreign key references employees,
	leavedate date,
	reason varchar(100) check(reason in('sick','vacation','maternity','paternity'))
);

select *from employees;
insert into empleave values(1,101,'2024-03-01','vacation'),
(2,101,'2024-03-01','sick'),
(3,107,'2025-01-03','vacation'),
(4,109,'2025-11-13','maternity'),
(5,113,'2025-06-30','paternity'),
(6,145,'2025-12-19','vacation'),
(7,126,'2025-01-19','sick'),
(8,178,'2024-06-13','vacation'),
(9,192,'2024-11-16','maternity'),
(10,100,'2024-03-21','paternity');

insert into empleave values(18,10,'2024-03-01','sick')

--create a view by name empleavesummary to list employee_id, first_name,last_name
--totalleave
create view empleavesummary as
select e.employee_id, first_name, last_name, count(*) total_leave
from employees e join empleave el
on e.employee_id=el.employee_id
group by e.employee_id,first_name,last_name

select *from empleavesummary;

select top 2* from empleavesummary order by total_leave desc;
