--Find min, max salary of all employees who earn sal>10000
select min(salary), max(salary) from employees
where salary>10000;

--Find the average salary for all  employees in each department
select department_id, AVG(salary) as avg_salary from employees
group by department_id;

--Find the average salary for all employees in each department with average salary>5000
select department_id, AVG(salary) as avg_salary from employees
group by department_id
having avg(salary)>5000;

--Find the employee names and their manager's last name 
select e.employee_id, e.first_name, e.last_name, m.last_name from employees e
left join employees m on e.manager_id = m.employee_id;

--Find the department names and the number of employees working in them
select d.department_name, count(*) from employees e
left join departments d on e.department_id=d.department_id
group by d.department_name;