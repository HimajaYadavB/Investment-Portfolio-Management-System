--1. List the first_name, last_name of all employees who work in a department with >5 employees in it
select first_name, last_name from employees where department_id in(
	select department_id from employees group by department_id having count(*)>5); 



--2. Create table as EMP_SA_MGR to list the first_name, last_name of all employees who work in job_id 'SA_MAN'
create table EMP_SA_MGR (
	first_name varchar(50),
	last_name varchar(50)
);
insert into EMP_SA_MGR 
	select first_name, last_name from employees where job_id in(
		select job_id from jobs where job_title='Sales Manager');

select *from EMP_SA_MGR;

--3. List employee_id, first_name, last_name, salary, department_id of all the employeess ranked 
--based on salary desc order from each department
select employee_id, first_name, last_name, salary, department_id, 
rank() over (partition by department_id order by salary desc) as salary_rank
FROM employees;


--4. Create a view with the above query to list only the top ranked employees from each department
create view topempvw as select *from (
	select employee_id, first_name, last_name, salary, department_id, 
	rank() over (partition by department_id order by salary desc) as salary_rank
FROM employees) as rankedemp where salary_rank=1;

select *from topempvw;

--5. Create a view to list department_name, countofemployees, 
--minimumsalary only if countofemp>4 and maxsal>10000
create view deptminvw as
select department_name, count(*) count_of_employees, min(salary) minimum_salary
from employees e join departments d on e.department_id = d.department_id
group by department_name
having count(*)>4 and max(salary)>10000

select *from deptminvw;

select *from emp_details1