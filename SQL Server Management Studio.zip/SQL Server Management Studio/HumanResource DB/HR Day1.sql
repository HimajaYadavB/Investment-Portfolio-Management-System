select *from employees;

select *from employees where salary>11000;
select *from employees where hire_date between '2000-01-01' and '2000-12-31'; 

select first_name, last_name, salary, salary*12 as annual_salary from employees;

select distinct department_id from employees;

