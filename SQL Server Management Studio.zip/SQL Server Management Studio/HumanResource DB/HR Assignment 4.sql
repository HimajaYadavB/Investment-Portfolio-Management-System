--Create a stored procedure to accept the  department_id
--and get the count of employees in that department_id
create or alter procedure getempcount @dno int
as
begin
	select @dno department_id,count(*) head_count from employees where department_id=@dno
end

exec getempcount 10;

--Create a stored procedure to accept the department_id, min_sal , max_sal 
--(salary range)use cursor and display the first_name,last_name,salary of the employees 
--from the given department_id earning salary in given range (handle all exceptions)                                                                                                                                                                                                                                              
create or alter procedure getsalofemp @dno int, @lsal int, @hsal int
as
begin
declare @fname varchar(20), @lname varchar(20), @sal int;
declare cc cursor for select first_name, last_name, salary 
from employees where department_id=@dno and salary between @lsal and @hsal;
open cc
fetch next from cc into @fname, @lname, @sal;
while @@FETCH_STATUS=0
begin
	print 'First Name: '+@fname+', Last Name: '+@lname+', Salary: '+convert(char(10),@sal)
	fetch next from cc into @fname, @lname, @sal;
end
close cc
deallocate cc
end

exec getsalofemp 10, 200, 15000


select *from employees

--Create a trigger to stop Insert Update and DELETE operations on employees table on 
--Saturday's and Sunday's
create trigger tremp on employees for insert, update, delete
as
begin
if datepart(WEEKDAY, GETDATE()) in (1,7)
begin
	print 'DML operations are restricted on Saturday and Sunday'
	rollback transaction;
end
end
