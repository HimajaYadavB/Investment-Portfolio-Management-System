select *from employees;
select *from departments;
select *from dependents;
select *from locations;


select *from employees where salary>11000;

select *from employees where hire_date between '2000-01-01' and '2000-12-31'; 
select *from employees where hire_date like '2000%';

select first_name, last_name, salary, salary*12 as annual_salary from employees;

select e.employee_id, e.first_name, e.last_name, d.department_name from employees e
left join departments d on e.department_id=d.department_id;