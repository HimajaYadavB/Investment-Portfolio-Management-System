--1. Filter the Sales table to show only sales with a total_price greater than $100.
select *from sales where total_price>100;

--2. Filter the Products table to show only products in the 'Electronics' category.
select *from products where category='electronics'

--3. Retrieve the sale_id and total_price from the Sales table for sales made on January 3, 2024.
select sale_id, total_price from sales where sale_date='2024-01-03';

--4. Retrieve the product_id and product_name from the Products table for products with a unit_price greater than $100.
select product_id, product_name from products where unit_price>100;

--5. Calculate the total revenue generated from all sales in the Sales table.
select sum(total_price) total_revenue from sales;

--6. Calculate the average unit_price of products in the Products table.
select avg(unit_price) 'average unit price' from products;

--7. Calculate the total quantity_sold from the Sales table.
select sum(quantity_sold) quantity_sold from sales;

--8.Count Sales Per Day from the Sales table
select sale_date, count(*) total from sales group by sale_date; 

--9. Retrieve product_name and unit_price from the Products table with the Highest Unit Price
select product_name, unit_price from products where unit_price=(select max(unit_price) from products);

--10. Retrieve the sale_id, product_id, and total_price from the Sales table for sales with a quantity_sold greater than 4.
select sale_id, product_id, total_price from sales where quantity_sold>4;

--11. Retrieve the product_name and unit_price from the Products table, ordering the results by unit_price in descending order.
select product_name, unit_price from products order by unit_price desc;

--12. Retrieve the total_price of all sales, rounding the values to two decimal places.
select round(sum(total_price),2) from sales;

--13. Retrieve the sale_id and sale_date from the Sales table, formatting the sale_date as 'YYYY-MM-DD'.
select sale_id, format(sale_date,'yyyy-MM-dd') formatted_date from sales;

--14. Calculate the total revenue generated from sales of products in the 'Electronics' category.
select sum(total_price) from sales where product_id in (select product_id from products where category='Electronics')

select sum(total_price) from sales s join products p on s.product_id=p.product_id where category='Electronics';

--15. Retrieve the product_name and unit_price from the Products table, filtering the unit_price to show 
--only values between $20 and $600.
select product_name, unit_price from products where unit_price between 20 and 600;

--16. Calculate the total quantity_sold of products in the 'Electronics' category.
select sum(quantity_sold) from sales s join products p on s.product_id=p.product_id where category='Electronics'

--17. Retrieve the product_name and total_price from the Sales table, calculating the 
--total_price as quantity_sold multiplied by unit_price.
select product_name, (quantity_sold * unit_price) total_price 
from sales s join products p on s.product_id=p.product_id

--18. Identify the Most Frequently Sold Product from Sales table
select top 1 product_id, count(*) cc from sales group by product_id order by cc

--19. Find the Products Not Sold from Products table
select product_id from products where product_id not in(select product_id from sales)

--20. Calculate the total revenue generated from sales for each product category.
select category, sum(total_price) from sales s join products p on s.product_id=p.product_id group by category;

--21. Find the product category with the highest average unit price.
select top 1 category from products 
group by category order by avg(unit_price) desc

--22. Identify products with total sales exceeding 30.
select product_name from sales s join products p on s.product_id=p.product_id 
group by product_name
having sum(total_price) >30;

--23. Count the number of sales made in each month.
select format(sale_date,'yyyy-MM'), count(*) from sales group by format(sale_date,'yyyy-MM')

--24. Retrieve Sales Details for Products with 'Smart' in Their Name
select s.*, product_name from sales s join products p on s.product_id=p.product_id where product_name like '%smart%'

--25. Determine the average quantity sold for products with a unit price greater than $100.
select product_name, avg(quantity_sold) from sales s 
join products p on s.product_id=p.product_id where unit_price>100
group by product_name 

select AVG(quantity_sold) from sales s 
join products p on s.product_id=p.product_id where unit_price>100

--26. Retrieve the product name and total sales revenue for each product.
select product_name, sum(total_price) ss from sales s 
join products p on s.product_id=p.product_id
group by product_name order by ss desc

--27. List all sales along with the corresponding product names.
select product_name, s.* from sales s join products p on s.product_id=p.product_id

--28. Retrieve the product name and total sales revenue for each product.
select product_name, sum(total_price) 
from sales s join products p on s.product_id=p.product_id
group by product_name;

--29. Rank products based on total sales revenue.
select product_name, sum(total_price) ss, 
rank() over(order by sum(total_price) desc)
from sales s join Products p on s.product_id=p.product_id
group by product_name

--30. Categorize sales as "High", "Medium", or "Low" based on total price (e.g., > $200 is High, $100-$200 is Medium, < $100 is Low).
select *,
case
	when total_price > 200 then 'High'
	when total_price between 100 and 200 then 'Medium'
	else 'Low'
end as sales_cat from Sales;

--31. Identify sales where the quantity sold is greater than the average quantity sold.
select *from sales where quantity_sold>(select avg(quantity_sold)from sales);

--32. Extract the month and year from the sale date and count the number of sales for each month.
select format(sale_date, 'yyyy-MM'), count(*) from sales group by format(sale_date, 'yyyy-MM')

--33. Calculate the number of days between the current date and the sale date for each sale.
select sale_id, DATEDIFF(day, sale_date, getdate()) from sales

--34. Identify sales made during weekdays versus weekends.
select 
case 
	when datepart(weekday, sale_date) in (1,7) then 'weekend'
	else 'weekday'
end as sale_type, 
count(*) total_sales, 
sum(total_price) total_revenue
from sales
group by case 
	when datepart(weekday, sale_date) in (1,7) then 'weekend'
	else 'weekday'
end;

--35. List the Top 3 Products by Revenue Contribution Percentage
select top 3 product_name, sum(total_price) total_revenue, sum(total_price)/(select sum(total_price) from sales) *100 revenue_percentage
from sales s join Products p on s.product_id=p.product_id 
group by product_name 
order by revenue_percentage desc;

--36. Write a query to create a view named Total_Sales that displays the total sales amount for each 
--product along with their names and categories.
create view Total_Sales as 
select product_name, category, sum(total_price) total_sales
from sales s join Products p on s.product_id=p.product_id
group by product_name, category

select *from Total_Sales

--37. Retrieve the product details (name, category, unit price) for products that have a quantity sold 
--greater than the average quantity sold across all products.
select product_name, category, unit_price
from sales s join Products p on s.product_id=p.product_id
where quantity_sold>(select avg(quantity_sold)from sales);

--38. Explain the significance of indexing in SQL databases and provide an example scenario where indexing 
--could significantly improve query performance in the given schema.
select sale_id,sale_date from sales where sale_date='2024-01-03';
create nonclustered index sale_date_idx on sales(sale_date);
select sale_id,sale_date from sales where sale_date='2024-01-03';

--39.  Add a foreign key constraint to the Sales table that references the product_id column in the Products table.
alter table sales add constraint pid_fk foreign key(product_id) references products(product_id)

--40. Create a view named Top_Products that lists the top 3 products based on the total quantity sold.
create view Top_Products as 
select top 3 product_name, sum(quantity_sold) qs from sales s join Products p on s.product_id=p.product_id
group by product_name
order by qs desc;

select *from Top_Products

--41. Create a query that lists the product names along with their corresponding sales count.
select product_name, count(*)
from sales s join Products p on s.product_id=p.product_id
group by product_name

--42. Write a query to find all sales where the total price is greater than the average total price of all sales.
select *from sales where total_price>(select avg(total_price) from sales)

--43. Add a check constraint to the quantity_sold column in the Sales table to ensure that the quantity sold is always greater than zero.
alter table sales add constraint qs_ck check(quantity_sold>0)

INSERT INTO Sales (sale_id, product_id, quantity_sold, sale_date, total_price) VALUES
(6, 101, -5, '2024-01-01', 2500.00)

--44. Create a view named Product_Sales_Info that displays product details along with the total number of sales made for each product.
create view Product_Sales_Info as 
select product_name, count(*) total_sales
from sales s join Products p on s.product_id=p.product_id
group by product_name

select *from Product_Sales_Info

--45. Develop a stored procedure named Update_Unit_Price that updates the unit price 
--of a product in the Products table based on the provided product_id.

--46. Implement a transaction that inserts a new product into the Products table and then adds a corresponding sale record 
--into the Sales table, ensuring that both operations are either fully completed or fully rolled back.

--47. Write a query that calculates the total revenue generated from each category of products for the year 2024.
select category, sum(total_price) from sales s join Products p on s.product_id=p.product_id
where year(sale_date)='2024'
group by category

